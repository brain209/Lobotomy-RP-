# Solución: Texturas Desordenadas en Minecraft Bedrock

## Problema
Las texturas generadas por IA (Leonardo AI) aparecen desordenadas en el juego porque no coinciden con el UV mapping del modelo 3D.

## Causa
- Los modelos de Minecraft usan **UV mapping** específico
- Cada cubo del modelo tiene coordenadas UV que indican qué parte de la textura usar
- Las texturas de IA son imágenes completas, no layouts UV

## Solución 1: Usar Modelos Simplificados (RECOMENDADO)

He actualizado el modelo de Snow Queen a un formato **humanoide estándar** similar al jugador de Minecraft:

### Ventajas:
- ✓ Compatible con texturas simples
- ✓ Más fácil de texturizar
- ✓ Funciona mejor con IA generativa
- ✓ Layout UV estándar de 64x64

### Estructura del modelo:
- **Cabeza**: 8x8x8 bloques
- **Cuerpo**: 8x12x4 bloques  
- **Brazos**: 4x12x4 bloques cada uno
- **Piernas**: 4x12x4 bloques cada una

## Solución 2: Convertir Texturas Existentes

Usa el script `CONVERTIR_TEXTURA_MINECRAFT.py`:

```bash
python CONVERTIR_TEXTURA_MINECRAFT.py
```

Esto convertirá tus texturas actuales al formato UV correcto.

## Solución 3: Crear Texturas Desde Cero con Layout Correcto

### Layout UV Estándar (64x64):

```
+--------+--------+--------+--------+
|  Top   | Bottom |        |        |  0-16
| Head   | Head   |        |        |
+--------+--------+--------+--------+
| Right  | Front  | Left   | Back   |  16-32
| Head   | Head   | Head   | Head   |
+--------+--------+--------+--------+
| Leg    | Body   | Arm    |        |  32-48
| Top    | Top    | Top    |        |
+--------+--------+--------+--------+
| Leg    | Body   | Arm    |        |  48-64
| Sides  | Sides  | Sides  |        |
+--------+--------+--------+--------+
```

## Próximos Pasos

1. **Probar el nuevo modelo de Snow Queen** - Ya está actualizado
2. **Actualizar otros modelos problemáticos** al formato simplificado
3. **Regenerar texturas** con el layout correcto
4. **Usar Blockbench** (opcional) para editar modelos visualmente

## Herramientas Recomendadas

- **Blockbench**: Editor visual de modelos para Minecraft
  - Descarga: https://www.blockbench.net/
  - Permite ver el modelo + textura en tiempo real
  - Exporta directamente a formato Bedrock

- **Paint.NET / GIMP**: Para editar texturas manualmente
  - Usa la plantilla de 64x64 del layout UV

## Modelos que Necesitan Actualización

Estos modelos probablemente tienen el mismo problema:
- [ ] big_bird
- [ ] judgement_bird  
- [ ] small_beak
- [ ] apocalypse_bird
- [ ] long_arms
- [ ] big_eyes
- [ ] laetitia
- [ ] laetitia_spider
- [ ] knight_despair
- [ ] funeral_butterflies
- [ ] queen_hatred
- [ ] queen_hatred_hysteric
- [ ] void_dream
- [ ] void_dream_transformed
- [x] snow_queen (ACTUALIZADO)

## Notas Importantes

- El formato UV **debe coincidir exactamente** entre modelo y textura
- Minecraft Bedrock usa el formato de modelo `.geo.json`
- Las texturas deben ser PNG con transparencia (RGBA)
- Tamaño recomendado: 64x64 píxeles (puede ser 128x128 o 256x256)
