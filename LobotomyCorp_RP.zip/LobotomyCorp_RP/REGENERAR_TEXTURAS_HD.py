"""
Regenera las texturas HD usando los modelos actuales y texturas originales de Leonardo AI
"""

from PIL import Image, ImageEnhance, ImageFilter
import json
import os

def analizar_modelo_uv(modelo_path):
    """Analiza un modelo .geo.json y extrae información de UV mapping"""
    with open(modelo_path, 'r', encoding='utf-8') as f:
        modelo = json.load(f)
    
    geometry = modelo['minecraft:geometry'][0]
    texture_width = geometry['description']['texture_width']
    texture_height = geometry['description']['texture_height']
    
    cubos = []
    for bone in geometry['bones']:
        if 'cubes' in bone:
            for cube in bone['cubes']:
                if 'uv' in cube:
                    cubos.append({
                        'bone': bone['name'],
                        'origin': cube['origin'],
                        'size': cube['size'],
                        'uv': cube['uv'],
                        'inflate': cube.get('inflate', 0)
                    })
    
    return {
        'texture_width': texture_width,
        'texture_height': texture_height,
        'cubos': cubos
    }

def mapear_textura_hd(imagen_ia_path, modelo_path, output_path):
    """
    Mapea una textura de IA al UV del modelo en alta resolución
    """
    # Cargar imagen de IA
    img_ia = Image.open(imagen_ia_path).convert('RGBA')
    
    # Analizar modelo
    info_modelo = analizar_modelo_uv(modelo_path)
    
    # Crear textura vacía del tamaño del modelo
    textura = Image.new('RGBA', 
                        (info_modelo['texture_width'], info_modelo['texture_height']), 
                        (0, 0, 0, 0))
    
    # Upscale de la imagen IA para mejor calidad
    img_work = img_ia.resize((128, 128), Image.Resampling.LANCZOS)
    
    # Aplicar mejoras a la imagen source
    img_work = img_work.filter(ImageFilter.SHARPEN)
    enhancer = ImageEnhance.Contrast(img_work)
    img_work = enhancer.enhance(1.2)
    enhancer = ImageEnhance.Color(img_work)
    img_work = enhancer.enhance(1.15)
    
    # Mapear cada cubo del modelo
    for cubo in info_modelo['cubos']:
        uv_x, uv_y = cubo['uv']
        size_x, size_y, size_z = cubo['size']
        bone_name = cubo['bone'].lower()
        
        # Determinar región source según el bone
        if 'head' in bone_name:
            source_region = img_work.crop((32, 0, 96, 48))
        elif 'crown' in bone_name or 'hair' in bone_name:
            source_region = img_work.crop((24, 0, 104, 32))
        elif 'body' in bone_name or 'torso' in bone_name:
            source_region = img_work.crop((32, 40, 96, 80))
        elif 'dress' in bone_name or 'skirt' in bone_name:
            source_region = img_work.crop((16, 64, 112, 96))
        elif 'leg' in bone_name or 'foot' in bone_name:
            source_region = img_work.crop((40, 88, 88, 128))
        elif 'arm' in bone_name:
            if 'left' in bone_name:
                source_region = img_work.crop((0, 40, 32, 80))
            else:
                source_region = img_work.crop((96, 40, 128, 80))
        elif 'hand' in bone_name:
            if 'left' in bone_name:
                source_region = img_work.crop((0, 80, 32, 96))
            else:
                source_region = img_work.crop((96, 80, 128, 96))
        elif 'wing' in bone_name or 'tail' in bone_name:
            source_region = img_work.crop((48, 80, 80, 112))
        elif 'spear' in bone_name or 'weapon' in bone_name or 'ice' in bone_name:
            source_region = img_work.crop((96, 0, 128, 32))
        elif 'particle' in bone_name:
            source_region = img_work.crop((112, 112, 128, 128))
        else:
            source_region = img_work.crop((40, 40, 88, 88))
        
        # Calcular dimensiones UV
        width_uv = int(abs(size_x) * 2 + abs(size_z) * 2)
        height_uv = int(abs(size_z) + abs(size_y))
        
        # Redimensionar y pegar
        try:
            if width_uv > 0 and height_uv > 0:
                source_resized = source_region.resize((width_uv, height_uv), Image.Resampling.LANCZOS)
                textura.paste(source_resized, (int(uv_x), int(uv_y)))
        except Exception as e:
            pass
    
    # Guardar
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    textura.save(output_path)
    print(f"  ✓ Textura HD regenerada: {os.path.basename(output_path)} ({info_modelo['texture_width']}x{info_modelo['texture_height']})")
    
    return textura

def procesar_entidad(nombre_entidad, base_path="."):
    """Procesa una entidad específica"""
    modelo_path = os.path.join(base_path, f"models/entity/{nombre_entidad}.geo.json")
    textura_ia_path = os.path.join(base_path, f"textures/entity/{nombre_entidad}.png")
    output_path = os.path.join(base_path, f"textures/entity/{nombre_entidad}_hd.png")
    
    if not os.path.exists(modelo_path):
        print(f"  ✗ No se encontró el modelo")
        return False
    
    if not os.path.exists(textura_ia_path):
        print(f"  ✗ No se encontró la textura original")
        return False
    
    try:
        mapear_textura_hd(textura_ia_path, modelo_path, output_path)
        return True
    except Exception as e:
        print(f"  ✗ Error: {e}")
        return False

def procesar_todas():
    """Procesa todas las entidades"""
    if os.path.exists("models/entity"):
        base_path = "."
    elif os.path.exists("LobotomyCorp_RP/models/entity"):
        base_path = "LobotomyCorp_RP"
    else:
        print("Error: No se encontró el directorio models/entity")
        return
    
    entidades = [
        'snow_queen',
        'punishing_bird',
        'punishing_bird_angry',
        'one_sin',
        'fairy_festival',
        'spider_bud',
        'void_dream',
        'void_dream_transformed',
        'der_freischutz',
        'funeral_butterflies',
        'knight_despair',
        'queen_hatred',
        'queen_hatred_hysteric',
    ]
    
    print("=== Regenerando Texturas HD ===\n")
    
    exitosos = 0
    for entidad in entidades:
        print(f"Procesando: {entidad}")
        if procesar_entidad(entidad, base_path):
            exitosos += 1
    
    print(f"\n✓ {exitosos} texturas HD regeneradas")
    print("Las texturas ahora están optimizadas para los modelos actuales")

if __name__ == "__main__":
    procesar_todas()
