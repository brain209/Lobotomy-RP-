"""
Script para aplicar las mejoras a las entidades:
1. Usa modelos mejorados
2. Usa texturas HD
3. Regenera el mapeo UV con mayor resolución
"""

import os
import shutil
import json

def aplicar_mejoras_entidad(nombre_entidad, base_path="."):
    """Aplica mejoras a una entidad específica"""
    
    # Rutas
    modelo_mejorado = os.path.join(base_path, f"models/entity/{nombre_entidad}_mejorado.geo.json")
    modelo_actual = os.path.join(base_path, f"models/entity/{nombre_entidad}.geo.json")
    
    textura_hd = os.path.join(base_path, f"textures/entity/{nombre_entidad}_hd.png")
    
    entity_file = os.path.join(base_path, f"entity/{nombre_entidad}.entity.json")
    
    cambios = []
    
    # 1. Si existe modelo mejorado, usarlo
    if os.path.exists(modelo_mejorado):
        # Backup del modelo original
        backup = modelo_actual + ".backup"
        if not os.path.exists(backup):
            shutil.copy2(modelo_actual, backup)
        
        # Copiar modelo mejorado
        shutil.copy2(modelo_mejorado, modelo_actual)
        cambios.append(f"  ✓ Modelo mejorado aplicado")
    
    # 2. Actualizar entity para usar textura HD
    if os.path.exists(textura_hd) and os.path.exists(entity_file):
        with open(entity_file, 'r', encoding='utf-8') as f:
            entity_data = json.load(f)
        
        # Actualizar referencia de textura
        if 'minecraft:client_entity' in entity_data:
            desc = entity_data['minecraft:client_entity']['description']
            if 'textures' in desc:
                for key in desc['textures']:
                    old_texture = desc['textures'][key]
                    # Cambiar _mapped por _hd
                    if '_mapped' in old_texture:
                        new_texture = old_texture.replace('_mapped', '_hd')
                        desc['textures'][key] = new_texture
                        cambios.append(f"  ✓ Textura actualizada a HD: {key}")
        
        # Guardar cambios
        with open(entity_file, 'w', encoding='utf-8') as f:
            json.dump(entity_data, f, indent=2)
    
    return cambios

def procesar_todas():
    """Aplica mejoras a todas las entidades"""
    
    # Detectar directorio base
    if os.path.exists("models/entity"):
        base_path = "."
    elif os.path.exists("LobotomyCorp_RP/models/entity"):
        base_path = "LobotomyCorp_RP"
    else:
        print("Error: No se encontró el directorio models/entity")
        return
    
    entidades = [
        'snow_queen',
        'punishing_bird',
        'punishing_bird_angry',
        'one_sin',
        'fairy_festival',
        'spider_bud',
        'void_dream',
        'void_dream_transformed',
        'der_freischutz',
        'funeral_butterflies',
        'knight_despair',
        'queen_hatred',
        'queen_hatred_hysteric',
    ]
    
    print("=== Aplicando Mejoras a Entidades ===\n")
    
    for entidad in entidades:
        print(f"Procesando: {entidad}")
        cambios = aplicar_mejoras_entidad(entidad, base_path)
        
        if cambios:
            for cambio in cambios:
                print(cambio)
        else:
            print("  - Sin cambios")
    
    print("\n✓ Mejoras aplicadas")
    print("\nPróximos pasos:")
    print("1. Recarga el mundo de Minecraft")
    print("2. Las entidades ahora usan texturas HD (128x128)")
    print("3. Los modelos mejorados tienen más detalles")

if __name__ == "__main__":
    procesar_todas()
