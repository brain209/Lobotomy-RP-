"""
Genera texturas pixel art funcionales desde cero para cada entidad
Basado en las descripciones de Lobotomy Corporation
"""

from PIL import Image, ImageDraw
import os

def crear_textura_base(width, height, color_base):
    """Crea una textura base con color sólido"""
    img = Image.new('RGBA', (width, height), color_base)
    return img

def dibujar_cubo_uv(draw, x, y, width, height, depth, color_principal, color_sombra):
    """Dibuja un cubo en formato UV de Minecraft"""
    # Top
    draw.rectangle([x + depth, y, x + depth + width, y + depth], fill=color_principal)
    # Bottom
    draw.rectangle([x + depth + width, y, x + depth + width*2, y + depth], fill=color_sombra)
    
    # Right side
    draw.rectangle([x, y + depth, x + depth, y + depth + height], fill=color_sombra)
    # Front
    draw.rectangle([x + depth, y + depth, x + depth + width, y + depth + height], fill=color_principal)
    # Left side
    draw.rectangle([x + depth + width, y + depth, x + depth + width + depth, y + depth + height], fill=color_sombra)
    # Back
    draw.rectangle([x + depth + width + depth, y + depth, x + depth + width*2 + depth, y + depth + height], fill=color_principal)

# === DEFINICIONES DE ENTIDADES ===

def crear_snow_queen():
    """Snow Queen / Frost Splinter - Reina de hielo"""
    texture = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
    draw = ImageDraw.Draw(texture)
    
    # Colores
    ice_blue = (176, 224, 230, 255)
    ice_dark = (135, 206, 235, 255)
    white = (255, 255, 255, 255)
    
    # Cabeza (0,0) - 8x8x8
    dibujar_cubo_uv(draw, 0, 0, 8, 8, 8, ice_blue, ice_dark)
    # Ojos
    draw.rectangle([10, 10, 11, 11], fill=(100, 150, 200, 255))
    draw.rectangle([13, 10, 14, 11], fill=(100, 150, 200, 255))
    
    # Cuerpo (16,20) - 8x12x4
    dibujar_cubo_uv(draw, 16, 16, 8, 12, 4, white, ice_blue)
    
    # Vestido (0,32) - 16x12x16
    dibujar_cubo_uv(draw, 0, 32, 16, 12, 16, ice_blue, ice_dark)
    
    # Brazos (40,20) - 4x12x4 cada uno
    dibujar_cubo_uv(draw, 40, 20, 4, 12, 4, white, ice_blue)
    dibujar_cubo_uv(draw, 48, 20, 4, 12, 4, white, ice_blue)
    
    return texture

def crear_punishing_bird():
    """Punishing Bird / Beak - Pájaro pequeño blanco"""
    texture = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
    draw = ImageDraw.Draw(texture)
    
    # Colores
    white = (255, 255, 255, 255)
    gray = (200, 200, 200, 255)
    red = (255, 0, 0, 255)
    black = (0, 0, 0, 255)
    
    # Cabeza (0,0) - 6x6x6
    dibujar_cubo_uv(draw, 0, 0, 6, 6, 6, white, gray)
    # Ojos
    draw.rectangle([8, 8, 9, 9], fill=black)
    draw.rectangle([11, 8, 12, 9], fill=black)
    # Pico
    draw.rectangle([9, 10, 11, 11], fill=(255, 200, 0, 255))
    
    # Cuerpo (16,20) - 6x8x4
    dibujar_cubo_uv(draw, 16, 16, 6, 8, 4, white, gray)
    # Marca roja en el pecho
    draw.rectangle([20, 22, 22, 24], fill=red)
    
    # Alas (40,20) - 3x6x2 cada una
    dibujar_cubo_uv(draw, 40, 20, 3, 6, 2, white, gray)
    dibujar_cubo_uv(draw, 48, 20, 3, 6, 2, white, gray)
    
    return texture

def crear_punishing_bird_angry():
    """Punishing Bird Angry - Versión enfurecida roja"""
    texture = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
    draw = ImageDraw.Draw(texture)
    
    # Colores
    red = (220, 20, 60, 255)
    dark_red = (139, 0, 0, 255)
    black = (0, 0, 0, 255)
    
    # Cabeza (0,0) - 7x7x7
    dibujar_cubo_uv(draw, 0, 0, 7, 7, 7, red, dark_red)
    # Ojos rojos brillantes
    draw.rectangle([8, 8, 10, 10], fill=(255, 0, 0, 255))
    draw.rectangle([12, 8, 14, 10], fill=(255, 0, 0, 255))
    
    # Cuerpo (16,20) - 7x10x5
    dibujar_cubo_uv(draw, 16, 16, 7, 10, 5, dark_red, black)
    # Boca/mandíbula en el pecho
    draw.rectangle([20, 22, 23, 25], fill=black)
    
    # Alas (40,20) - 4x8x3 cada una
    dibujar_cubo_uv(draw, 40, 20, 4, 8, 3, red, dark_red)
    dibujar_cubo_uv(draw, 48, 20, 4, 8, 3, red, dark_red)
    
    return texture

def crear_one_sin():
    """One Sin / Penitence - Calavera con manzana"""
    texture = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
    draw = ImageDraw.Draw(texture)
    
    # Colores
    bone = (245, 245, 220, 255)
    brown = (139, 69, 19, 255)
    gold = (255, 215, 0, 255)
    
    # Cabeza/Calavera (0,0) - 8x8x8
    dibujar_cubo_uv(draw, 0, 0, 8, 8, 8, bone, (200, 200, 180, 255))
    # Ojos vacíos
    draw.rectangle([9, 9, 10, 11], fill=(50, 50, 50, 255))
    draw.rectangle([14, 9, 15, 11], fill=(50, 50, 50, 255))
    
    # Cuerpo (16,20) - 8x12x4
    dibujar_cubo_uv(draw, 16, 16, 8, 12, 4, brown, (100, 50, 10, 255))
    # Manzana dorada
    draw.ellipse([20, 20, 24, 24], fill=gold)
    
    # Brazos (40,20) - 4x12x4 cada uno
    dibujar_cubo_uv(draw, 40, 20, 4, 12, 4, bone, (200, 200, 180, 255))
    dibujar_cubo_uv(draw, 48, 20, 4, 12, 4, bone, (200, 200, 180, 255))
    
    # Piernas (0,48) - 4x12x4 cada una
    dibujar_cubo_uv(draw, 0, 48, 4, 12, 4, brown, (100, 50, 10, 255))
    dibujar_cubo_uv(draw, 8, 48, 4, 12, 4, brown, (100, 50, 10, 255))
    
    return texture

def crear_fairy_festival():
    """Fairy Festival - Hada rosa"""
    texture = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
    draw = ImageDraw.Draw(texture)
    
    # Colores
    pink = (255, 182, 193, 255)
    dark_pink = (255, 105, 180, 255)
    white = (255, 255, 255, 255)
    
    # Cabeza (0,0) - 7x7x7
    dibujar_cubo_uv(draw, 0, 0, 7, 7, 7, pink, dark_pink)
    # Ojos
    draw.rectangle([8, 9, 9, 10], fill=(100, 50, 100, 255))
    draw.rectangle([12, 9, 13, 10], fill=(100, 50, 100, 255))
    
    # Cuerpo (16,20) - 6x10x4
    dibujar_cubo_uv(draw, 16, 16, 6, 10, 4, white, pink)
    
    # Vestido (0,32) - 12x10x12
    dibujar_cubo_uv(draw, 0, 32, 12, 10, 12, dark_pink, pink)
    
    # Brazos (40,20) - 3x10x3 cada uno
    dibujar_cubo_uv(draw, 40, 20, 3, 10, 3, pink, dark_pink)
    dibujar_cubo_uv(draw, 48, 20, 3, 10, 3, pink, dark_pink)
    
    return texture

def crear_spider_bud():
    """Spider Bud - Araña oscura"""
    texture = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
    draw = ImageDraw.Draw(texture)
    
    # Colores
    black = (30, 30, 30, 255)
    dark_gray = (50, 50, 50, 255)
    red = (255, 0, 0, 255)
    
    # Cabeza (0,0) - 8x6x8
    dibujar_cubo_uv(draw, 0, 0, 8, 6, 8, black, dark_gray)
    # Ojos rojos múltiples
    draw.rectangle([8, 8, 9, 9], fill=red)
    draw.rectangle([11, 8, 12, 9], fill=red)
    draw.rectangle([14, 8, 15, 9], fill=red)
    
    # Cuerpo (16,20) - 10x8x8
    dibujar_cubo_uv(draw, 16, 16, 10, 8, 8, dark_gray, black)
    
    # Patas (simplificadas como brazos)
    dibujar_cubo_uv(draw, 40, 20, 2, 8, 2, black, dark_gray)
    dibujar_cubo_uv(draw, 48, 20, 2, 8, 2, black, dark_gray)
    
    return texture

# Función principal
def generar_todas():
    """Genera todas las texturas"""
    
    base_path = "LobotomyCorp_RP" if os.path.exists("LobotomyCorp_RP") else "."
    output_dir = os.path.join(base_path, "textures/entity")
    os.makedirs(output_dir, exist_ok=True)
    
    entidades = {
        'snow_queen': crear_snow_queen,
        'punishing_bird': crear_punishing_bird,
        'punishing_bird_angry': crear_punishing_bird_angry,
        'one_sin': crear_one_sin,
        'fairy_festival': crear_fairy_festival,
        'spider_bud': crear_spider_bud,
    }
    
    print("=== Generando Texturas Pixel Art ===\n")
    
    for nombre, funcion in entidades.items():
        try:
            texture = funcion()
            output_path = os.path.join(output_dir, f"{nombre}_pixelart.png")
            texture.save(output_path)
            print(f"✓ {nombre}: Textura generada")
        except Exception as e:
            print(f"✗ {nombre}: Error - {e}")
    
    print(f"\n✓ Texturas pixel art generadas en: {output_dir}")
    print("Estas son texturas funcionales básicas")
    print("Ahora crea los modelos únicos para cada una")

if __name__ == "__main__":
    generar_todas()
