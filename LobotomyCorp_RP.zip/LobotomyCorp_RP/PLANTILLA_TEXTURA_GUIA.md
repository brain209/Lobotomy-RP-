# Guía para Crear Texturas con Leonardo AI

## Formato Correcto para Minecraft Bedrock

Para que las texturas funcionen correctamente, necesitas generar imágenes que sigan el **layout UV de Minecraft**.

## Opción 1: Textura Simple (MÁS FÁCIL)

Genera una imagen de **64x64 píxeles** del personaje visto de frente, completo:

### Prompt para Leonardo AI:
```
pixel art, minecraft style, [NOMBRE_ENTIDAD], full body front view, 
64x64 pixels, simple design, clear colors, transparent background,
character standing straight, arms at sides, facing forward
```

### Ejemplos:
- **Snow Queen**: "ice queen, blue and white colors, frozen dress, crown"
- **Punishing Bird**: "small red bird, angry eyes, sharp beak, tiny wings"
- **Big Bird**: "large yellow bird, lamp on head, friendly appearance"

Luego usa el script `CONVERTIR_TEXTURA_MINECRAFT.py` para convertirla.

## Opción 2: Layout UV Completo (AVANZADO)

Genera una textura con el layout UV completo de Minecraft.

### Prompt para Leonardo AI:
```
minecraft texture template, 64x64 pixel art, UV map layout,
[NOMBRE_ENTIDAD] skin texture, all faces visible,
top view, front view, side view, back view arranged in grid,
pixel art style, clear colors, organized layout
```

### Estructura del Layout (64x64):

```
Píxeles 0-32 (altura 0-16): CABEZA
- (0,0): Lado derecho cabeza
- (8,0): Top cabeza  
- (16,0): Bottom cabeza
- (0,8): Lado derecho
- (8,8): Frente cabeza
- (16,8): Lado izquierdo
- (24,8): Atrás cabeza

Píxeles 0-40 (altura 16-32): CUERPO
- (16,16): Top cuerpo
- (20,16): Top cuerpo
- (28,16): Bottom cuerpo
- (16,20): Lado derecho cuerpo
- (20,20): Frente cuerpo
- (28,20): Lado izquierdo cuerpo
- (32,20): Atrás cuerpo

Píxeles 40-56 (altura 16-32): BRAZOS
- (40,16): Top brazo
- (44,16): Top brazo
- (48,16): Bottom brazo
- (40,20): Lado exterior brazo
- (44,20): Frente brazo
- (48,20): Lado interior brazo
- (52,20): Atrás brazo

Píxeles 0-16 (altura 16-32): PIERNAS
- (0,16): Top pierna
- (4,16): Top pierna
- (8,16): Bottom pierna
- (0,20): Lado exterior pierna
- (4,20): Frente pierna
- (8,20): Lado interior pierna
- (12,20): Atrás pierna
```

## Opción 3: Usar Blockbench (RECOMENDADO)

1. Descarga **Blockbench**: https://www.blockbench.net/
2. Abre el modelo `.geo.json` de la entidad
3. Crea/edita la textura directamente en Blockbench
4. Exporta la textura cuando esté lista

### Ventajas de Blockbench:
- ✓ Ves el modelo y textura en tiempo real
- ✓ Pintas directamente sobre el modelo 3D
- ✓ Genera el UV mapping automáticamente
- ✓ Exporta en formato correcto

## Consejos para Leonardo AI

### Configuración Recomendada:
- **Estilo**: Pixel Art / Minecraft Style
- **Resolución**: 64x64 o 128x128
- **Formato**: PNG con transparencia
- **Prompt negativo**: "blurry, realistic, 3d render, smooth"

### Palabras Clave Útiles:
- `pixel art`
- `minecraft style`
- `64x64 pixels`
- `simple colors`
- `flat design`
- `transparent background`
- `sprite sheet` (para layout UV)

## Proceso Recomendado

1. **Genera textura simple** con Leonardo AI (vista frontal)
2. **Convierte con script**: `python CONVERTIR_TEXTURA_MINECRAFT.py`
3. **Prueba en juego**
4. **Ajusta colores** si es necesario
5. **Repite** para otras entidades

## Texturas Prioritarias

Estas entidades NO tienen textura actualmente:
1. big_bird
2. judgement_bird
3. small_beak
4. apocalypse_bird
5. long_arms
6. big_eyes
7. laetitia
8. laetitia_spider

## Ejemplo de Workflow Completo

### Para "Big Bird" (Lamp):

1. **Prompt Leonardo AI**:
```
pixel art, minecraft style, large yellow bird with lamp on head,
full body front view, 64x64 pixels, friendly appearance,
glowing lamp, simple design, transparent background
```

2. **Guardar como**: `big_bird_raw.png`

3. **Convertir**:
```bash
# Copiar a textures/entity/
cp big_bird_raw.png LobotomyCorp_RP/textures/entity/

# Ejecutar script
cd LobotomyCorp_RP
python CONVERTIR_TEXTURA_MINECRAFT.py
```

4. **Actualizar client entity** para usar `big_bird_fixed.png`

5. **Probar en juego**

## Troubleshooting

### La textura sigue desordenada:
- Verifica que el modelo use el formato simplificado
- Asegúrate de usar la textura `_fixed.png` generada por el script
- Revisa que la textura sea 64x64 píxeles

### Los colores no se ven bien:
- Ajusta el prompt de Leonardo AI
- Usa colores más saturados
- Evita degradados complejos

### La textura es muy pixelada:
- Genera en 128x128 en lugar de 64x64
- El script la redimensionará automáticamente
