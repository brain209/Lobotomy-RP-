"""
Script para mejorar la calidad de las texturas mapeadas
- Aumenta la nitidez
- Mejora el contraste
- Upscale para más detalle
"""

from PIL import Image, ImageEnhance, ImageFilter
import os

def mejorar_textura(input_path, output_path, scale=2):
    """
    Mejora una textura haciéndola más nítida y detallada
    """
    # Cargar imagen
    img = Image.open(input_path).convert('RGBA')
    
    # 1. Upscale (aumentar resolución)
    new_size = (img.width * scale, img.height * scale)
    img_upscaled = img.resize(new_size, Image.Resampling.LANCZOS)
    
    # 2. Aplicar sharpening (nitidez)
    img_sharp = img_upscaled.filter(ImageFilter.SHARPEN)
    img_sharp = img_sharp.filter(ImageFilter.SHARPEN)  # Aplicar dos veces
    
    # 3. Mejorar contraste
    enhancer = ImageEnhance.Contrast(img_sharp)
    img_contrast = enhancer.enhance(1.3)  # 30% más contraste
    
    # 4. Mejorar saturación de color
    enhancer = ImageEnhance.Color(img_contrast)
    img_final = enhancer.enhance(1.2)  # 20% más saturación
    
    # Guardar
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    img_final.save(output_path)
    print(f"  ✓ Mejorada: {os.path.basename(output_path)} ({img.width}x{img.height} → {img_final.width}x{img_final.height})")
    
    return img_final

def procesar_todas():
    """Mejora todas las texturas _mapped.png"""
    
    # Detectar directorio base
    if os.path.exists("textures/entity"):
        base_path = "."
    elif os.path.exists("LobotomyCorp_RP/textures/entity"):
        base_path = "LobotomyCorp_RP"
    else:
        print("Error: No se encontró el directorio textures/entity")
        return
    
    textures_dir = os.path.join(base_path, "textures/entity")
    
    # Buscar todas las texturas _mapped.png
    archivos = [f for f in os.listdir(textures_dir) if f.endswith('_mapped.png')]
    
    if not archivos:
        print("No se encontraron texturas _mapped.png")
        return
    
    print(f"=== Mejorando {len(archivos)} Texturas ===\n")
    
    for archivo in archivos:
        nombre_base = archivo.replace('_mapped.png', '')
        input_path = os.path.join(textures_dir, archivo)
        output_path = os.path.join(textures_dir, f"{nombre_base}_hd.png")
        
        try:
            print(f"Procesando: {nombre_base}")
            mejorar_textura(input_path, output_path, scale=2)
        except Exception as e:
            print(f"  ✗ Error: {e}")
    
    print(f"\n✓ Texturas HD generadas con sufijo _hd.png")
    print("Estas texturas tienen:")
    print("  - 2x resolución (128x128 o 256x256)")
    print("  - Mayor nitidez")
    print("  - Mejor contraste y saturación")

if __name__ == "__main__":
    procesar_todas()
