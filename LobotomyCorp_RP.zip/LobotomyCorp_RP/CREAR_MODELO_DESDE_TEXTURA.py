"""
Analiza una textura de Leonardo AI y crea automáticamente un modelo 3D que coincida
Detecta formas, proporciones y detalles para generar el modelo perfecto
"""

from PIL import Image, ImageDraw
import json
import os
import numpy as np

def detectar_silueta(imagen):
    """Detecta la silueta del personaje en la imagen"""
    # Convertir a array numpy
    img_array = np.array(imagen)
    
    # Detectar píxeles no transparentes
    alpha = img_array[:, :, 3]
    mask = alpha > 50
    
    # Encontrar límites
    rows = np.any(mask, axis=1)
    cols = np.any(mask, axis=0)
    
    if not rows.any() or not cols.any():
        return None
    
    y_min, y_max = np.where(rows)[0][[0, -1]]
    x_min, x_max = np.where(cols)[0][[0, -1]]
    
    return {
        'x_min': int(x_min),
        'x_max': int(x_max),
        'y_min': int(y_min),
        'y_max': int(y_max),
        'width': int(x_max - x_min),
        'height': int(y_max - y_min),
        'center_x': int((x_min + x_max) / 2),
        'center_y': int((y_min + y_max) / 2)
    }

def analizar_proporciones(imagen):
    """Analiza las proporciones del personaje"""
    silueta = detectar_silueta(imagen)
    if not silueta:
        return None
    
    height = silueta['height']
    width = silueta['width']
    
    # Dividir en secciones verticales
    y_min = silueta['y_min']
    y_max = silueta['y_max']
    
    # Detectar cabeza (top 20-25%)
    head_end = y_min + int(height * 0.25)
    
    # Detectar torso (25-60%)
    torso_start = head_end
    torso_end = y_min + int(height * 0.60)
    
    # Detectar parte inferior (60-100%)
    lower_start = torso_end
    lower_end = y_max
    
    # Analizar ancho en cada sección
    img_array = np.array(imagen)
    alpha = img_array[:, :, 3]
    
    def get_width_at_y(y):
        row = alpha[y, :]
        mask = row > 50
        if not mask.any():
            return 0
        cols = np.where(mask)[0]
        return int(cols[-1] - cols[0])
    
    head_width = get_width_at_y(int((y_min + head_end) / 2))
    torso_width = get_width_at_y(int((torso_start + torso_end) / 2))
    lower_width = get_width_at_y(int((lower_start + lower_end) / 2))
    
    # Detectar si tiene piernas o vestido
    tiene_piernas = lower_width < torso_width * 0.8
    
    # Detectar brazos (laterales)
    mid_y = int((torso_start + torso_end) / 2)
    center_x = silueta['center_x']
    
    # Buscar píxeles a los lados
    left_arm_detected = False
    right_arm_detected = False
    
    for x in range(silueta['x_min'], center_x - int(head_width/2)):
        if alpha[mid_y, x] > 50:
            left_arm_detected = True
            break
    
    for x in range(center_x + int(head_width/2), silueta['x_max']):
        if alpha[mid_y, x] > 50:
            right_arm_detected = True
            break
    
    return {
        'height': height,
        'width': width,
        'head_height': head_end - y_min,
        'head_width': head_width,
        'torso_height': torso_end - torso_start,
        'torso_width': torso_width,
        'lower_height': lower_end - lower_start,
        'lower_width': lower_width,
        'tiene_piernas': tiene_piernas,
        'tiene_brazos': left_arm_detected or right_arm_detected,
        'silueta': silueta
    }

def crear_modelo_desde_analisis(nombre_entidad, proporciones):
    """Crea un modelo 3D basado en las proporciones detectadas"""
    
    if not proporciones:
        return None
    
    # Calcular escala (normalizar a altura de ~32 bloques)
    target_height = 32
    scale = target_height / proporciones['height']
    
    # Dimensiones en bloques de Minecraft
    head_height = max(6, int(proporciones['head_height'] * scale * 0.8))
    head_width = max(6, int(proporciones['head_width'] * scale * 0.6))
    
    torso_height = max(8, int(proporciones['torso_height'] * scale * 0.7))
    torso_width = max(6, int(proporciones['torso_width'] * scale * 0.5))
    
    lower_height = max(8, int(proporciones['lower_height'] * scale * 0.7))
    lower_width = int(proporciones['lower_width'] * scale * 0.5)
    
    # Crear estructura del modelo
    bones = [
        {
            "name": "root",
            "pivot": [0, 0, 0]
        }
    ]
    
    current_y = 0
    
    # Piernas o base
    if proporciones['tiene_piernas']:
        # Tiene piernas separadas
        leg_width = max(3, torso_width // 2 - 1)
        bones.extend([
            {
                "name": "left_leg",
                "parent": "root",
                "pivot": [-leg_width//2, lower_height, 0],
                "cubes": [{
                    "origin": [-leg_width, 0, -leg_width//2],
                    "size": [leg_width, lower_height, leg_width],
                    "uv": [0, 48]
                }]
            },
            {
                "name": "right_leg",
                "parent": "root",
                "pivot": [leg_width//2, lower_height, 0],
                "cubes": [{
                    "origin": [0, 0, -leg_width//2],
                    "size": [leg_width, lower_height, leg_width],
                    "uv": [16, 48]
                }]
            }
        ])
        current_y = lower_height
    else:
        # Vestido o falda
        bones.append({
            "name": "dress",
            "parent": "root",
            "pivot": [0, lower_height//2, 0],
            "cubes": [{
                "origin": [-lower_width//2, 0, -lower_width//2],
                "size": [lower_width, lower_height, lower_width],
                "uv": [0, 48],
                "inflate": 0.2
            }]
        })
        current_y = lower_height
    
    # Torso
    body_y = current_y
    bones.append({
        "name": "body",
        "parent": "root",
        "pivot": [0, body_y + torso_height//2, 0],
        "cubes": [{
            "origin": [-torso_width//2, body_y, -torso_width//4],
            "size": [torso_width, torso_height, torso_width//2],
            "uv": [16, 32]
        }]
    })
    
    # Brazos
    if proporciones['tiene_brazos']:
        arm_width = max(2, torso_width // 4)
        arm_height = max(8, torso_height)
        arm_y = body_y + torso_height - 2
        
        bones.extend([
            {
                "name": "left_arm",
                "parent": "body",
                "pivot": [-torso_width//2 - arm_width//2, arm_y, 0],
                "cubes": [{
                    "origin": [-torso_width//2 - arm_width, body_y, -arm_width//2],
                    "size": [arm_width, arm_height, arm_width],
                    "uv": [40, 32]
                }]
            },
            {
                "name": "right_arm",
                "parent": "body",
                "pivot": [torso_width//2 + arm_width//2, arm_y, 0],
                "cubes": [{
                    "origin": [torso_width//2, body_y, -arm_width//2],
                    "size": [arm_width, arm_height, arm_width],
                    "uv": [48, 32]
                }]
            }
        ])
    
    # Cabeza
    head_y = body_y + torso_height
    bones.append({
        "name": "head",
        "parent": "body",
        "pivot": [0, head_y, 0],
        "cubes": [{
            "origin": [-head_width//2, head_y, -head_width//2],
            "size": [head_width, head_height, head_width],
            "uv": [0, 0]
        }]
    })
    
    # Crear modelo completo
    modelo = {
        "format_version": "1.12.0",
        "minecraft:geometry": [{
            "description": {
                "identifier": f"geometry.{nombre_entidad}",
                "texture_width": 64,
                "texture_height": 64,
                "visible_bounds_width": max(3, lower_width // 4),
                "visible_bounds_height": max(3, (head_y + head_height) // 8),
                "visible_bounds_offset": [0, (head_y + head_height) // 16, 0]
            },
            "bones": bones
        }]
    }
    
    return modelo

def procesar_entidad(nombre_entidad, base_path="."):
    """Procesa una entidad y crea su modelo automáticamente"""
    textura_path = os.path.join(base_path, f"textures/entity/{nombre_entidad}.png")
    
    if not os.path.exists(textura_path):
        print(f"  ✗ No se encontró la textura")
        return False
    
    try:
        # Cargar y analizar textura
        img = Image.open(textura_path).convert('RGBA')
        print(f"  Analizando textura {img.width}x{img.height}...")
        
        proporciones = analizar_proporciones(img)
        
        if not proporciones:
            print(f"  ✗ No se pudo detectar la silueta")
            return False
        
        print(f"  Proporciones detectadas:")
        print(f"    - Altura total: {proporciones['height']}px")
        print(f"    - Cabeza: {proporciones['head_height']}px ({proporciones['head_width']}px ancho)")
        print(f"    - Torso: {proporciones['torso_height']}px ({proporciones['torso_width']}px ancho)")
        print(f"    - Inferior: {proporciones['lower_height']}px ({proporciones['lower_width']}px ancho)")
        print(f"    - Tipo: {'Piernas' if proporciones['tiene_piernas'] else 'Vestido'}")
        print(f"    - Brazos: {'Sí' if proporciones['tiene_brazos'] else 'No'}")
        
        # Crear modelo
        modelo = crear_modelo_desde_analisis(nombre_entidad, proporciones)
        
        if not modelo:
            print(f"  ✗ No se pudo crear el modelo")
            return False
        
        # Guardar modelo
        output_path = os.path.join(base_path, f"models/entity/{nombre_entidad}_smart.geo.json")
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(modelo, f, indent=2)
        
        print(f"  ✓ Modelo inteligente creado: {os.path.basename(output_path)}")
        
        return True
        
    except Exception as e:
        print(f"  ✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return False

def procesar_todas():
    """Procesa todas las entidades"""
    # Siempre usar LobotomyCorp_RP como base
    base_path = "LobotomyCorp_RP" if os.path.exists("LobotomyCorp_RP") else "."
    
    print(f"Directorio base: {os.path.abspath(base_path)}\n")
    
    entidades = [
        'snow_queen',
        'punishing_bird',
        'punishing_bird_angry',
        'one_sin',
        'fairy_festival',
        'spider_bud',
        'void_dream',
        'void_dream_transformed',
        'der_freischutz',
        'funeral_butterflies',
        'knight_despair',
        'queen_hatred',
        'queen_hatred_hysteric',
    ]
    
    print("=== Creando Modelos Inteligentes desde Texturas ===\n")
    print("Este script analiza cada textura y crea un modelo 3D que coincide")
    print("con las proporciones y forma del personaje.\n")
    
    exitosos = 0
    for entidad in entidades:
        print(f"\nProcesando: {entidad}")
        if procesar_entidad(entidad, base_path):
            exitosos += 1
    
    print(f"\n\n=== Resumen ===")
    print(f"✓ {exitosos}/{len(entidades)} modelos creados exitosamente")
    print("\nLos modelos *_smart.geo.json están listos")
    print("Estos modelos se ajustan automáticamente a las proporciones de cada textura")

if __name__ == "__main__":
    try:
        import numpy
        procesar_todas()
    except ImportError:
        print("Error: Se requiere numpy")
        print("Instala con: py -m pip install numpy")
