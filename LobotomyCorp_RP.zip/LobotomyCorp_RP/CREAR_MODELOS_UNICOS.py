"""
Crea modelos únicos para cada entidad basándose en sus características
"""

import json
import os

def modelo_snow_queen():
    """Reina de hielo - elegante con vestido"""
    return {
        "format_version": "1.12.0",
        "minecraft:geometry": [{
            "description": {
                "identifier": "geometry.snow_queen",
                "texture_width": 64,
                "texture_height": 64
            },
            "bones": [
                {"name": "root", "pivot": [0, 0, 0]},
                {
                    "name": "dress",
                    "parent": "root",
                    "pivot": [0, 6, 0],
                    "cubes": [{"origin": [-8, 0, -8], "size": [16, 12, 16], "uv": [0, 32]}]
                },
                {
                    "name": "body",
                    "parent": "dress",
                    "pivot": [0, 18, 0],
                    "cubes": [{"origin": [-4, 12, -2], "size": [8, 12, 4], "uv": [16, 16]}]
                },
                {
                    "name": "head",
                    "parent": "body",
                    "pivot": [0, 24, 0],
                    "cubes": [{"origin": [-4, 24, -4], "size": [8, 8, 8], "uv": [0, 0]}]
                },
                {
                    "name": "left_arm",
                    "parent": "body",
                    "pivot": [-5, 22, 0],
                    "cubes": [{"origin": [-7, 12, -2], "size": [4, 12, 4], "uv": [40, 20]}]
                },
                {
                    "name": "right_arm",
                    "parent": "body",
                    "pivot": [5, 22, 0],
                    "cubes": [{"origin": [3, 12, -2], "size": [4, 12, 4], "uv": [48, 20]}]
                }
            ]
        }]
    }

def modelo_punishing_bird():
    """Pájaro pequeño - compacto"""
    return {
        "format_version": "1.12.0",
        "minecraft:geometry": [{
            "description": {
                "identifier": "geometry.punishing_bird",
                "texture_width": 64,
                "texture_height": 64
            },
            "bones": [
                {"name": "root", "pivot": [0, 0, 0]},
                {
                    "name": "body",
                    "parent": "root",
                    "pivot": [0, 4, 0],
                    "cubes": [{"origin": [-3, 2, -2], "size": [6, 8, 4], "uv": [16, 16]}]
                },
                {
                    "name": "head",
                    "parent": "body",
                    "pivot": [0, 10, -1],
                    "cubes": [{"origin": [-3, 10, -3], "size": [6, 6, 6], "uv": [0, 0]}]
                },
                {
                    "name": "left_wing",
                    "parent": "body",
                    "pivot": [-3, 8, 0],
                    "cubes": [{"origin": [-5, 4, -1], "size": [3, 6, 2], "uv": [40, 20]}]
                },
                {
                    "name": "right_wing",
                    "parent": "body",
                    "pivot": [3, 8, 0],
                    "cubes": [{"origin": [2, 4, -1], "size": [3, 6, 2], "uv": [48, 20]}]
                },
                {
                    "name": "tail",
                    "parent": "body",
                    "pivot": [0, 4, 2],
                    "cubes": [{"origin": [-1, 2, 2], "size": [2, 4, 3], "uv": [0, 48]}]
                }
            ]
        }]
    }

def modelo_punishing_bird_angry():
    """Pájaro enfurecido - más grande y agresivo"""
    return {
        "format_version": "1.12.0",
        "minecraft:geometry": [{
            "description": {
                "identifier": "geometry.punishing_bird_angry",
                "texture_width": 64,
                "texture_height": 64
            },
            "bones": [
                {"name": "root", "pivot": [0, 0, 0]},
                {
                    "name": "body",
                    "parent": "root",
                    "pivot": [0, 6, 0],
                    "cubes": [{"origin": [-3.5, 4, -2.5], "size": [7, 10, 5], "uv": [16, 16]}]
                },
                {
                    "name": "head",
                    "parent": "body",
                    "pivot": [0, 14, -1],
                    "cubes": [{"origin": [-3.5, 14, -3.5], "size": [7, 7, 7], "uv": [0, 0]}]
                },
                {
                    "name": "jaw",
                    "parent": "body",
                    "pivot": [0, 6, -2],
                    "cubes": [{"origin": [-2, 4, -3], "size": [4, 3, 2], "uv": [32, 0]}]
                },
                {
                    "name": "left_wing",
                    "parent": "body",
                    "pivot": [-3.5, 12, 0],
                    "cubes": [{"origin": [-6, 6, -1.5], "size": [4, 8, 3], "uv": [40, 20]}]
                },
                {
                    "name": "right_wing",
                    "parent": "body",
                    "pivot": [3.5, 12, 0],
                    "cubes": [{"origin": [2, 6, -1.5], "size": [4, 8, 3], "uv": [48, 20]}]
                }
            ]
        }]
    }

def modelo_one_sin():
    """Calavera con manzana - humanoide con piernas"""
    return {
        "format_version": "1.12.0",
        "minecraft:geometry": [{
            "description": {
                "identifier": "geometry.one_sin",
                "texture_width": 64,
                "texture_height": 64
            },
            "bones": [
                {"name": "root", "pivot": [0, 0, 0]},
                {
                    "name": "body",
                    "parent": "root",
                    "pivot": [0, 12, 0],
                    "cubes": [{"origin": [-4, 12, -2], "size": [8, 12, 4], "uv": [16, 16]}]
                },
                {
                    "name": "head",
                    "parent": "body",
                    "pivot": [0, 24, 0],
                    "cubes": [{"origin": [-4, 24, -4], "size": [8, 8, 8], "uv": [0, 0]}]
                },
                {
                    "name": "left_arm",
                    "parent": "body",
                    "pivot": [-5, 22, 0],
                    "cubes": [{"origin": [-7, 12, -2], "size": [4, 12, 4], "uv": [40, 20]}]
                },
                {
                    "name": "right_arm",
                    "parent": "body",
                    "pivot": [5, 22, 0],
                    "cubes": [{"origin": [3, 12, -2], "size": [4, 12, 4], "uv": [48, 20]}]
                },
                {
                    "name": "left_leg",
                    "parent": "root",
                    "pivot": [-2, 12, 0],
                    "cubes": [{"origin": [-4, 0, -2], "size": [4, 12, 4], "uv": [0, 48]}]
                },
                {
                    "name": "right_leg",
                    "parent": "root",
                    "pivot": [2, 12, 0],
                    "cubes": [{"origin": [0, 0, -2], "size": [4, 12, 4], "uv": [8, 48]}]
                }
            ]
        }]
    }

def modelo_fairy_festival():
    """Hada - pequeña y delicada con vestido"""
    return {
        "format_version": "1.12.0",
        "minecraft:geometry": [{
            "description": {
                "identifier": "geometry.fairy_festival",
                "texture_width": 64,
                "texture_height": 64
            },
            "bones": [
                {"name": "root", "pivot": [0, 0, 0]},
                {
                    "name": "dress",
                    "parent": "root",
                    "pivot": [0, 5, 0],
                    "cubes": [{"origin": [-6, 0, -6], "size": [12, 10, 12], "uv": [0, 32]}]
                },
                {
                    "name": "body",
                    "parent": "dress",
                    "pivot": [0, 15, 0],
                    "cubes": [{"origin": [-3, 10, -2], "size": [6, 10, 4], "uv": [16, 16]}]
                },
                {
                    "name": "head",
                    "parent": "body",
                    "pivot": [0, 20, 0],
                    "cubes": [{"origin": [-3.5, 20, -3.5], "size": [7, 7, 7], "uv": [0, 0]}]
                },
                {
                    "name": "left_arm",
                    "parent": "body",
                    "pivot": [-3.5, 18, 0],
                    "cubes": [{"origin": [-5, 10, -1.5], "size": [3, 10, 3], "uv": [40, 20]}]
                },
                {
                    "name": "right_arm",
                    "parent": "body",
                    "pivot": [3.5, 18, 0],
                    "cubes": [{"origin": [2, 10, -1.5], "size": [3, 10, 3], "uv": [48, 20]}]
                }
            ]
        }]
    }

def modelo_spider_bud():
    """Araña - cuerpo bajo y ancho"""
    return {
        "format_version": "1.12.0",
        "minecraft:geometry": [{
            "description": {
                "identifier": "geometry.spider_bud",
                "texture_width": 64,
                "texture_height": 64
            },
            "bones": [
                {"name": "root", "pivot": [0, 0, 0]},
                {
                    "name": "body",
                    "parent": "root",
                    "pivot": [0, 4, 0],
                    "cubes": [{"origin": [-5, 2, -4], "size": [10, 8, 8], "uv": [16, 16]}]
                },
                {
                    "name": "head",
                    "parent": "body",
                    "pivot": [0, 6, -4],
                    "cubes": [{"origin": [-4, 4, -8], "size": [8, 6, 8], "uv": [0, 0]}]
                },
                {
                    "name": "leg1",
                    "parent": "body",
                    "pivot": [-5, 4, -2],
                    "cubes": [{"origin": [-7, 0, -3], "size": [2, 8, 2], "uv": [40, 20]}]
                },
                {
                    "name": "leg2",
                    "parent": "body",
                    "pivot": [5, 4, -2],
                    "cubes": [{"origin": [5, 0, -3], "size": [2, 8, 2], "uv": [48, 20]}]
                },
                {
                    "name": "leg3",
                    "parent": "body",
                    "pivot": [-5, 4, 2],
                    "cubes": [{"origin": [-7, 0, 1], "size": [2, 8, 2], "uv": [40, 28]}]
                },
                {
                    "name": "leg4",
                    "parent": "body",
                    "pivot": [5, 4, 2],
                    "cubes": [{"origin": [5, 0, 1], "size": [2, 8, 2], "uv": [48, 28]}]
                }
            ]
        }]
    }

def guardar_modelos():
    """Guarda todos los modelos"""
    base_path = "LobotomyCorp_RP" if os.path.exists("LobotomyCorp_RP") else "."
    models_dir = os.path.join(base_path, "models/entity")
    
    modelos = {
        'snow_queen': modelo_snow_queen,
        'punishing_bird': modelo_punishing_bird,
        'punishing_bird_angry': modelo_punishing_bird_angry,
        'one_sin': modelo_one_sin,
        'fairy_festival': modelo_fairy_festival,
        'spider_bud': modelo_spider_bud,
    }
    
    print("=== Creando Modelos Únicos ===\n")
    
    for nombre, funcion in modelos.items():
        try:
            modelo = funcion()
            output_path = os.path.join(models_dir, f"{nombre}_unique.geo.json")
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(modelo, f, indent=2)
            print(f"✓ {nombre}: Modelo único creado")
        except Exception as e:
            print(f"✗ {nombre}: Error - {e}")
    
    print(f"\n✓ Modelos únicos guardados en: {models_dir}")

if __name__ == "__main__":
    guardar_modelos()
