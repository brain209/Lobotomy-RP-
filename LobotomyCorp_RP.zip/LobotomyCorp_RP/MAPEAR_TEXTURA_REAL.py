"""
Script para mapear correctamente texturas de Leonardo AI a modelos de Minecraft
Toma la textura completa y la redistribuye según el UV mapping del modelo
"""

from PIL import Image, ImageDraw
import json
import os

def analizar_modelo_uv(modelo_path):
    """Analiza un modelo .geo.json y extrae información de UV mapping"""
    with open(modelo_path, 'r', encoding='utf-8') as f:
        modelo = json.load(f)
    
    geometry = modelo['minecraft:geometry'][0]
    texture_width = geometry['description']['texture_width']
    texture_height = geometry['description']['texture_height']
    
    # Extraer todos los cubos con sus UVs
    cubos = []
    for bone in geometry['bones']:
        if 'cubes' in bone:
            for cube in bone['cubes']:
                if 'uv' in cube:
                    cubos.append({
                        'bone': bone['name'],
                        'origin': cube['origin'],
                        'size': cube['size'],
                        'uv': cube['uv']
                    })
    
    return {
        'texture_width': texture_width,
        'texture_height': texture_height,
        'cubos': cubos
    }

def mapear_textura_a_uv(imagen_ia_path, modelo_path, output_path):
    """
    Mapea una textura de IA (imagen completa del personaje) al UV del modelo
    """
    # Cargar imagen de IA
    img_ia = Image.open(imagen_ia_path).convert('RGBA')
    
    # Analizar modelo
    info_modelo = analizar_modelo_uv(modelo_path)
    
    # Crear textura vacía del tamaño correcto
    textura = Image.new('RGBA', 
                        (info_modelo['texture_width'], info_modelo['texture_height']), 
                        (0, 0, 0, 0))
    
    # Redimensionar imagen IA a un tamaño estándar para trabajar
    img_work = img_ia.resize((64, 64), Image.Resampling.LANCZOS)
    
    # Mapear cada cubo del modelo
    for cubo in info_modelo['cubos']:
        uv_x, uv_y = cubo['uv']
        size_x, size_y, size_z = cubo['size']
        bone_name = cubo['bone'].lower()
        
        # Determinar de qué parte de la imagen IA tomar los píxeles
        # según el nombre del bone
        
        if 'head' in bone_name or 'crown' in bone_name:
            # Cabeza: parte superior de la imagen
            source_region = img_work.crop((16, 0, 48, 24))
        elif 'body' in bone_name or 'torso' in bone_name:
            # Cuerpo: parte media
            source_region = img_work.crop((16, 20, 48, 40))
        elif 'dress' in bone_name or 'skirt' in bone_name:
            # Vestido: parte inferior media
            source_region = img_work.crop((8, 32, 56, 48))
        elif 'leg' in bone_name or 'foot' in bone_name:
            # Piernas: parte inferior
            source_region = img_work.crop((20, 44, 44, 64))
        elif 'arm' in bone_name:
            # Brazos: laterales
            if 'left' in bone_name:
                source_region = img_work.crop((0, 20, 16, 40))
            else:
                source_region = img_work.crop((48, 20, 64, 40))
        elif 'wing' in bone_name or 'tail' in bone_name:
            # Alas/cola: parte trasera
            source_region = img_work.crop((24, 40, 40, 56))
        elif 'spear' in bone_name or 'weapon' in bone_name:
            # Armas/accesorios: detalles
            source_region = img_work.crop((48, 0, 64, 16))
        else:
            # Por defecto: centro de la imagen
            source_region = img_work.crop((20, 20, 44, 44))
        
        # Calcular dimensiones UV para el cubo (formato estándar de Minecraft)
        # Un cubo 3D se despliega en 2D con este patrón:
        #     [top]
        # [L] [F] [R] [B]
        #     [bottom]
        
        width_uv = int(abs(size_x) * 2 + abs(size_z) * 2)
        height_uv = int(abs(size_z) + abs(size_y))
        
        # Redimensionar la región source al tamaño UV necesario
        try:
            source_resized = source_region.resize((width_uv, height_uv), Image.Resampling.LANCZOS)
            
            # Pegar en la posición UV
            textura.paste(source_resized, (int(uv_x), int(uv_y)))
        except Exception as e:
            print(f"    Advertencia en {bone_name}: {e}")
            pass
    
    # Guardar textura
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    textura.save(output_path)
    print(f"  ✓ Textura mapeada: {output_path}")
    
    return textura

def procesar_entidad(nombre_entidad, base_path="."):
    """Procesa una entidad específica"""
    modelo_path = os.path.join(base_path, f"models/entity/{nombre_entidad}.geo.json")
    textura_ia_path = os.path.join(base_path, f"textures/entity/{nombre_entidad}.png")
    output_path = os.path.join(base_path, f"textures/entity/{nombre_entidad}_mapped.png")
    
    if not os.path.exists(modelo_path):
        print(f"  ✗ No se encontró el modelo: {modelo_path}")
        return False
    
    if not os.path.exists(textura_ia_path):
        print(f"  ✗ No se encontró la textura: {textura_ia_path}")
        return False
    
    try:
        mapear_textura_a_uv(textura_ia_path, modelo_path, output_path)
        return True
    except Exception as e:
        print(f"  ✗ Error procesando {nombre_entidad}: {e}")
        import traceback
        traceback.print_exc()
        return False

def procesar_todas():
    """Procesa todas las entidades que tienen modelo y textura"""
    # Detectar directorio base
    if os.path.exists("models/entity"):
        base_path = "."
    elif os.path.exists("LobotomyCorp_RP/models/entity"):
        base_path = "LobotomyCorp_RP"
    else:
        print("Error: No se encontró el directorio models/entity")
        return
    
    print(f"Usando directorio base: {os.path.abspath(base_path)}\n")
    
    entidades = [
        'snow_queen',
        'punishing_bird',
        'punishing_bird_angry',
        'one_sin',
        'fairy_festival',
        'spider_bud',
        'void_dream',
        'void_dream_transformed',
        'der_freischutz',
        'funeral_butterflies',
        'knight_despair',
        'queen_hatred',
        'queen_hatred_hysteric',
    ]
    
    print("=== Mapeando Texturas de Leonardo AI a UV de Minecraft ===\n")
    
    exitosos = 0
    fallidos = 0
    
    for entidad in entidades:
        print(f"Procesando: {entidad}")
        if procesar_entidad(entidad, base_path):
            exitosos += 1
        else:
            fallidos += 1
    
    print(f"\n=== Resumen ===")
    print(f"Exitosos: {exitosos}")
    print(f"Fallidos: {fallidos}")
    
    if exitosos > 0:
        print(f"\n✓ Las texturas _mapped.png están listas")
        print("Estas texturas tienen los detalles de Leonardo AI mapeados al UV del modelo")
        print("\nAhora actualiza los archivos .entity.json para usar las texturas _mapped.png")

if __name__ == "__main__":
    procesar_todas()
