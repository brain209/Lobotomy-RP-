# 🎨 Instrucciones para Agregar Texturas Reales

## ⚠️ IMPORTANTE: Archivos PNG Reales Necesarios

Los archivos de texturas deben ser **imágenes PNG reales**, no archivos de texto. 

### 📋 Texturas Necesarias

Coloca estos archivos PNG en `LobotomyCorp_RP/textures/entity/`:

#### Prioridad Alta
- `fairy_festival.png` (64x64)
- `punishing_bird.png` (64x64) 
- `punishing_bird_angry.png` (64x64)
- `spider_bud.png` (64x64)
- `void_dream.png` (64x64)
- `void_dream_transformed.png` (64x64)

#### Prioridad Media  
- `der_freischutz.png` (64x64)
- `laetitia.png` (64x64)
- `laetitia_spider.png` (64x64)
- `snow_queen.png` (64x64)
- `queen_hatred.png` (64x64)
- `queen_hatred_hysteric.png` (64x64)
- `knight_despair.png` (64x64)

#### Prioridad Baja
- `big_bird.png` (128x128)
- `apocalypse_bird.png` (256x256)
- `small_beak.png` (64x64)
- `big_eyes.png` (64x64)
- `funeral_butterflies.png` (64x64)
- `judgement_bird.png` (128x128)
- `long_arms.png` (64x64)
- `one_sin.png` (64x64)

### 🛠️ Cómo Crear las Texturas

1. **Usar un editor de imágenes** (GIMP, Photoshop, Aseprite, etc.)
2. **Crear imagen nueva** con las dimensiones especificadas
3. **Dibujar la textura** siguiendo el estilo pixel art
4. **Guardar como PNG** con transparencia
5. **Colocar en** `LobotomyCorp_RP/textures/entity/`

### 🎯 Mientras Tanto

El addon funcionará perfectamente **sin las texturas PNG**. Las entidades aparecerán con texturas de placeholder pero todas las mecánicas funcionan al 100%.

### ✅ Una vez agregadas las texturas

Las entidades mostrarán las texturas personalizadas automáticamente.