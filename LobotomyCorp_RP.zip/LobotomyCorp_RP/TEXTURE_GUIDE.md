# Guía de Texturas - Lobotomy Corporation Resource Pack

Este documento describe las texturas necesarias para cada abnormalidad y cómo crearlas.

## 📁 Estructura de Texturas

Todas las texturas van en: `LobotomyCorp_RP/textures/entity/`

## 🎨 Especificaciones de Texturas por Entidad

### One Sin and Hundreds of Good Deeds
**Archivo**: `one_sin.png` (64x64)
**Descripción**: Cruz levitante con calavera y corona de espinas
- **Cruz**: Madera oscura con vetas, color #8B4513
- **Calavera**: Hueso blanquecino con sombras grises, ojos vacíos negros
- **Corona de espinas**: Espinas marrones entrelazadas, color #654321
- **Aura**: Resplandor dorado sutil alrededor, color #FFD700 con transparencia

### Fairy Festival  
**Archivo**: `fairy_festival.png` (64x64)
**Descripción**: Hada grande con alas brillantes
- **Cuerpo**: Rosa claro con detalles más oscuros, color #FFB6C1
- **Cabeza**: Rostro humanoide con expresión alegre
- **Alas**: Translúcidas con patrones de mariposa, colores iridiscentes
- **Detalles**: Purpurina y brillos, colores #FF69B4 y #DA70D6

### Punishing Bird
**Archivo**: `punishing_bird.png` (64x64)
**Descripción**: Pájaro pequeño blanco con marca roja en el pecho
- **Plumas**: Blanco puro #FFFFFF con sombras grises suaves
- **Pico**: Amarillo dorado #FFD700
- **Marca del pecho**: Rojo brillante #FF0000 en forma de corazón
- **Ojos**: Negros pequeños y redondos
- **Patas**: Amarillo naranja #FFA500

**Archivo**: `punishing_bird_angry.png` (64x64)
**Descripción**: Versión enojada completamente roja
- **Plumas**: Rojo intenso #DC143C con sombras más oscuras
- **Mandíbula del pecho**: Abierta mostrando dientes blancos afilados
- **Ojos**: Rojos brillantes con pupila negra
- **Aura de ira**: Partículas rojas alrededor

### Spider Bud
**Archivo**: `spider_bud.png` (64x64)  
**Descripción**: Saco oscuro con múltiples ojos rojos
- **Saco principal**: Gris muy oscuro #2F2F2F con textura rugosa
- **Ojos**: Múltiples ojos rojos #FF0000 de diferentes tamaños
- **Telarañas**: Hilos blancos semi-transparentes #F5F5F5
- **Sombras**: Negras profundas para dar volumen

### Void Dream
**Archivo**: `void_dream.png` (64x64)
**Descripción**: Oveja flotante con colores místicos
- **Lana**: Blanco esponjoso #FFFFFF con toques azulados
- **Cabeza**: Púrpura #9932CC con gradiente
- **Cuernos**: Espirales dorados #DAA520
- **Orejas**: Rosa suave #FFB6C1
- **Ojos del cuerpo**: Verde #00FF00 y púrpura #8A2BE2
- **Ojos de la cabeza**: Cerrados con pestañas largas

**Archivo**: `void_dream_transformed.png` (64x64)
**Descripción**: Versión transformada más oscura
- **Colores más intensos y oscuros**
- **Aura de energía negra alrededor**
- **Ojos abiertos y brillantes**

### Big Bird
**Archivo**: `big_bird.png` (128x128)
**Descripción**: Pájaro grande negro sin plumas con múltiples ojos
- **Cuerpo**: Negro mate #000000 con textura de piel
- **Ojos**: 17+ ojos amarillos #FFFF00 distribuidos por el cuerpo
- **Pico**: Negro con interior rojo #8B0000, dientes blancos
- **Brazos**: Largos y delgados, sin plumas
- **Linterna**: Estructura metálica con llama interior dorada
- **Sombras**: Grises para dar profundidad

**Archivo**: `big_bird_eyes.png` (128x128)
**Descripción**: Capa de ojos emisiva
- **Fondo transparente**
- **Solo los ojos amarillos brillantes**
- **Efecto de resplandor**

### Queen of Hatred
**Archivo**: `queen_hatred.png` (64x64)
**Descripción**: Figura femenina elegante con vestido
- **Vestido**: Rojo oscuro #8B0000 con detalles dorados
- **Piel**: Pálida con tono grisáceo
- **Cabello**: Negro largo y ondulado
- **Corona**: Dorada con gemas rojas
- **Expresión**: Serena pero amenazante

**Archivo**: `queen_hatred_hysteric.png` (64x64)  
**Descripción**: Versión histérica transformada
- **Colores más intensos y caóticos**
- **Cabello alborotado**
- **Ojos rojos brillantes**
- **Aura de energía roja**

## 🛠️ Herramientas Recomendadas

1. **Aseprite** - Para pixel art detallado
2. **GIMP** - Editor gratuito con buenas herramientas
3. **Photoshop** - Para efectos avanzados
4. **Paint.NET** - Alternativa simple y efectiva

## 📐 Consejos de Diseño

### Paleta de Colores por Tipo de Daño
- **RED**: #FF0000, #DC143C, #8B0000
- **WHITE**: #FFFFFF, #F5F5F5, #E0E0E0  
- **BLACK**: #000000, #2F2F2F, #696969
- **PALE**: #87CEEB, #B0E0E6, #ADD8E6

### Técnicas Generales
1. **Contraste alto** para visibilidad en el juego
2. **Sombras definidas** para dar volumen
3. **Detalles mínimos** pero expresivos
4. **Colores saturados** para impacto visual
5. **Transparencias** para efectos especiales

### Efectos Especiales
- **Ojos brillantes**: Usar colores emisivos
- **Auras**: Gradientes con transparencia
- **Texturas orgánicas**: Ruido sutil para realismo
- **Metales**: Reflejos y highlights

## 📋 Lista de Archivos Necesarios

### Texturas Básicas (Requeridas)
- `one_sin.png` (64x64)
- `fairy_festival.png` (64x64)  
- `punishing_bird.png` (64x64)
- `punishing_bird_angry.png` (64x64)
- `spider_bud.png` (64x64)
- `void_dream.png` (64x64)
- `void_dream_transformed.png` (64x64)
- `big_bird.png` (128x128)
- `big_bird_eyes.png` (128x128)
- `queen_hatred.png` (64x64)
- `queen_hatred_hysteric.png` (64x64)

### Texturas Adicionales (Opcionales)
- `der_freischutz.png` (64x64)
- `funeral_butterflies.png` (64x64)
- `laetitia.png` (64x64)
- `laetitia_spider.png` (64x64)
- `snow_queen.png` (64x64)
- `knight_despair.png` (64x64)
- `judgement_bird.png` (128x128)
- `apocalypse_bird.png` (256x256)

## 🎯 Prioridades de Creación

1. **Alta prioridad**: One Sin, Punishing Bird, Big Bird
2. **Media prioridad**: Fairy Festival, Spider Bud, Void Dream
3. **Baja prioridad**: Queen of Hatred, resto de abnormalidades

## 📝 Notas Importantes

- Todas las texturas deben ser **potencias de 2** (64x64, 128x128, etc.)
- Usar **formato PNG** con transparencia cuando sea necesario
- **Mantener consistencia** en el estilo artístico
- **Probar en el juego** regularmente para ajustar colores y contraste
- **Hacer respaldos** de las texturas originales

---

Una vez creadas las texturas, simplemente colócalas en la carpeta `textures/entity/` y el Resource Pack las cargará automáticamente.