"""
Aplica el sistema UV completo: modelos y texturas
"""

import os
import shutil
import json

def aplicar_sistema_uv(nombre_entidad, base_path="."):
    """Aplica modelo UV y actualiza entity file"""
    
    modelo_uv = os.path.join(base_path, f"models/entity/{nombre_entidad}_uv.geo.json")
    modelo_actual = os.path.join(base_path, f"models/entity/{nombre_entidad}.geo.json")
    entity_file = os.path.join(base_path, f"entity/{nombre_entidad}.entity.json")
    
    if not os.path.exists(modelo_uv):
        return False
    
    # Backup
    if os.path.exists(modelo_actual):
        backup = modelo_actual + ".backup2"
        if not os.path.exists(backup):
            shutil.copy2(modelo_actual, backup)
    
    # Aplicar modelo UV
    shutil.copy2(modelo_uv, modelo_actual)
    
    # Actualizar entity file para usar textura UV
    if os.path.exists(entity_file):
        with open(entity_file, 'r', encoding='utf-8') as f:
            entity_data = json.load(f)
        
        if 'minecraft:client_entity' in entity_data:
            desc = entity_data['minecraft:client_entity']['description']
            if 'textures' in desc:
                for key in desc['textures']:
                    old_texture = desc['textures'][key]
                    # Cambiar a _uv
                    base_name = old_texture.split('/')[-1]
                    if '_' in base_name:
                        base_name = base_name.split('_')[0]
                    desc['textures'][key] = f"textures/entity/{base_name}_uv"
        
        with open(entity_file, 'w', encoding='utf-8') as f:
            json.dump(entity_data, f, indent=2)
    
    return True

def procesar_todas():
    """Aplica sistema UV a todas las entidades"""
    
    base_path = "LobotomyCorp_RP" if os.path.exists("LobotomyCorp_RP") else "."
    
    entidades = [
        'snow_queen',
        'punishing_bird',
        'punishing_bird_angry',
        'one_sin',
        'fairy_festival',
        'spider_bud',
        'void_dream',
        'void_dream_transformed',
        'der_freischutz',
        'funeral_butterflies',
        'knight_despair',
        'queen_hatred',
        'queen_hatred_hysteric',
    ]
    
    print("=== Aplicando Sistema UV Completo ===\n")
    
    exitosos = 0
    for entidad in entidades:
        if aplicar_sistema_uv(entidad, base_path):
            print(f"✓ {entidad}: Sistema UV aplicado")
            exitosos += 1
        else:
            print(f"✗ {entidad}: Error")
    
    print(f"\n✓ {exitosos}/{len(entidades)} entidades actualizadas")
    print("\n¡LISTO! Recarga el mundo de Minecraft")
    print("Las entidades ahora usan:")
    print("  - Texturas UV correctas (*_uv.png)")
    print("  - Modelos funcionales (*_uv.geo.json)")

if __name__ == "__main__":
    procesar_todas()
