# 🎨 GUÍA PARA CREAR TEXTURAS CORRECTAS

## 📋 **ESPECIFICACIONES TÉCNICAS**

### **Formato Requerido:**
- **Formato**: PNG (sin compresión)
- **Resolución**: Potencias de 2 (64x64, 128x128, 256x256)
- **Canales**: RGBA (con transparencia)
- **Profundidad**: 32 bits por píxel

---

## 🎯 **TEXTURAS POR PRIORIDAD**

### **🔥 ALTA PRIORIDAD (Más Usadas)**

#### **1. Punishing Bird** (64x64)
```
Archivo: punishing_bird.png
Colores:
- Base: Blanco puro (#FFFFFF)
- Pico: Amarillo dorado (#FFD700)
- Marca pecho: Rojo brillante (#FF0000)
- Ojos: Negro (#000000)
- Sombras: Gris claro (#E0E0E0)

Diseño:
- Cuerpo: Ovalado blanco
- Cabeza: Circular blanca
- Pico: Triángulo amarillo pequeño
- Marca: Corazón rojo en el pecho
- Alas: Pequeñas, blancas con bordes grises
```

#### **2. Punishing Bird Angry** (64x64)
```
Archivo: punishing_bird_angry.png
Colores:
- Base: Rojo intenso (#DC143C)
- Mandíbula: Rojo más oscuro (#8B0000)
- Dientes: Blanco (#FFFFFF)
- Ojos: Rojo brillante (#FF0000)
- Sombras: Rojo muy oscuro (#4B0000)

Diseño:
- Igual que normal pero todo rojo
- Mandíbula abierta en el pecho
- Dientes afilados visibles
- Expresión más agresiva
```

#### **3. Fairy Festival** (64x64)
```
Archivo: fairy_festival.png
Colores:
- Cuerpo: Rosa claro (#FFB6C1)
- Alas: Rosa fuerte (#FF69B4)
- Cabello: Rosa más oscuro (#DA70D6)
- Vestido: Rosa pastel (#FFC0CB)
- Brillos: Blanco (#FFFFFF)

Diseño:
- Figura humanoide pequeña
- Alas de mariposa grandes
- Cabello largo y ondulado
- Vestido fluido
- Partículas brillantes alrededor
```

#### **4. Spider Bud** (64x64)
```
Archivo: spider_bud.png
Colores:
- Saco: Gris muy oscuro (#2F2F2F)
- Ojos: Rojo brillante (#FF0000)
- Telarañas: Blanco semi-transparente (#F5F5F5)
- Sombras: Negro (#000000)

Diseño:
- Saco ovalado grande
- 5-8 ojos rojos de diferentes tamaños
- Hilos de telaraña cruzados
- Textura rugosa en el saco
```

### **⭐ MEDIA PRIORIDAD**

#### **5. Big Bird** (128x128)
```
Archivo: big_bird.png
Colores:
- Cuerpo: Negro mate (#000000)
- Ojos: Amarillo brillante (#FFFF00)
- Interior pico: Rojo oscuro (#8B0000)
- Dientes: Blanco (#FFFFFF)

Diseño:
- Pájaro grande sin plumas
- 17+ ojos amarillos distribuidos
- Pico grande con dientes
- Brazos largos y delgados
- Linterna en una mano
```

#### **6. Void Dream** (64x64)
```
Archivo: void_dream.png
Colores:
- Lana: Blanco esponjoso (#FFFFFF)
- Cabeza: Púrpura (#9932CC)
- Cuernos: Dorado (#DAA520)
- Orejas: Rosa suave (#FFB6C1)

Diseño:
- Cuerpo de oveja flotante
- Cabeza púrpura con cuernos
- Ojos cerrados con pestañas
- Lana esponjosa y suave
```

#### **7. Void Dream Transformed** (64x64)
```
Archivo: void_dream_transformed.png
Colores:
- Igual que normal pero más oscuro
- Aura negra alrededor
- Ojos abiertos y brillantes
- Colores más saturados

Diseño:
- Versión más siniestra
- Ojos abiertos amenazantes
- Aura de energía oscura
- Expresión más agresiva
```

### **🔸 BAJA PRIORIDAD**

#### **8. Queen of Hatred** (64x64)
```
Archivo: queen_hatred.png
Colores:
- Vestido: Rojo oscuro (#8B0000)
- Corona: Dorado (#FFD700)
- Piel: Pálida (#F5F5DC)
- Cabello: Negro (#000000)

Diseño:
- Figura femenina elegante
- Vestido largo y fluido
- Corona dorada ornamentada
- Expresión serena pero fría
```

#### **9. Queen of Hatred Hysteric** (64x64)
```
Archivo: queen_hatred_hysteric.png
Colores:
- Vestido: Rojo más intenso (#FF0000)
- Aura: Rojo brillante
- Ojos: Rojos brillantes
- Cabello: Alborotado

Diseño:
- Versión más caótica
- Cabello desordenado
- Aura de energía roja
- Expresión histérica
```

#### **10. Huevos Especiales** (64x64 cada uno)

**Small Beak:**
```
Archivo: small_beak.png
Colores:
- Cáscara: Rojo (#FF0000)
- Pico: Amarillo (#FFD700)
- Aura: Rojo brillante semi-transparente

Diseño:
- Huevo ovalado rojo
- Pico pequeño sobresaliendo
- Aura roja alrededor
```

**Long Arms:**
```
Archivo: long_arms.png
Colores:
- Cáscara: Azul claro (#87CEEB)
- Vendas: Blanco (#FFFFFF)
- Brazos: Gris (#808080)
- Aura: Azul pálido

Diseño:
- Huevo con vendas
- Brazos largos extendidos
- Aura azul pálida
```

**Big Eyes:**
```
Archivo: big_eyes.png
Colores:
- Cáscara: Gris oscuro (#2F2F2F)
- Ojos: Varios colores brillantes
- Aura: Negra semi-transparente

Diseño:
- Huevo negro
- Múltiples ojos grandes
- Aura oscura alrededor
```

---

## 🤖 **HERRAMIENTAS DE IAMENDADAS**

### **Opción 1: GIMP (Gratuito)**
1. Nuevo → 64x64 píxeles
2. Rellenar con color base
3. Añadir detalles con pincel
4. Exportar como PNG

### **Opción 2: Paint.NET (Gratuito)**
1. Archivo → Nuevo → 64x64
2. Usar herramientas de forma
3. Aplicar colores sólidos
4. Guardar como PNG

### **Opción 3: Aseprite (Pixel Art)**
1. Perfecto para pixel art
2. Herramientas especializadas
3. Animaciones (futuro)

### **Opción 4: Online (Pixilart.com)**
1. Editor online gratuito
2. 64x64 canvas
3. Descargar como PNG

---

## 📐 **PLANTILLAS DE COLORES**

### **Por Nivel de Riesgo:**

**ZAYIN (Seguros):**
- Colores suaves y claros
- Tonos pastel
- Apariencia amigable

**TETH (Básicos):**
- Colores primarios
- Contrastes moderados
- Algunos detalles amenazantes

**HE (Intermedios):**
- Colores más intensos
- Contrastes fuertes
- Detalles más complejos

**WAW (Peligrosos):**
- Colores oscuros e intensos
- Rojos, negros, grises
- Apariencia amenazante

**ALEPH (Extremos):**
- Colores apocalípticos
- Negro con acentos brillantes
- Máximo contraste

---

## 🎯 **PROCESO PASO A PASO**

### **Para cada textura:**

1. **Crear archivo PNG** (64x64 o 128x128)
2. **Fondo transparente** (importante)
3. **Color base** según especificaciones
4. **Añadir detalles** principales
5. **Sombras y highlights** básicos
6. **Verificar resolución** (potencia de 2)
7. **Guardar sin compresión**
8. **Probar en el juego**

### **Verificación:**
```bash
# Probar cada textura
/tag @s add lc:spawn:[entidad]
```

---

## 🚀 **TEXTURAS MÍNIMAS FUNCIONALES**

Si necesitas texturas básicas que funcionen inmediatamente:

### **Colores Sólidos Simples:**
- **Punishing Bird**: Blanco con punto rojo
- **Fairy Festival**: Rosa sólido
- **Spider Bud**: Gris oscuro con puntos rojos
- **Big Bird**: Negro con puntos amarillos
- **Void Dream**: Blanco con toque púrpura

### **Crear en 5 minutos:**
1. Abrir Paint/GIMP
2. 64x64 píxeles
3. Rellenar con color principal
4. Añadir 2-3 detalles básicos
5. Guardar como PNG
6. Copiar a `textures/entity/`

---

## ✅ **LISTA DE VERIFICACIÓN**

### **Antes de usar:**
- [ ] Resolución correcta (64x64, 128x128, etc.)
- [ ] Formato PNG
- [ ] Fondo transparente donde sea necesario
- [ ] Colores según especificaciones
- [ ] Archivo no corrupto
- [ ] Nombre correcto del archivo

### **Después de crear:**
- [ ] Copiar a `LobotomyCorp_RP/textures/entity/`
- [ ] Probar en el juego
- [ ] Verificar que no hay errores
- [ ] Ajustar si es necesario

---

*Una vez creadas las texturas básicas, el addon funcionará completamente sin errores.*