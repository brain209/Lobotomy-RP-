#!/usr/bin/env python3
"""
Generador de Texturas Básicas para Lobotomy Corporation
Crea texturas PNG simples pero funcionales para eliminar errores
"""

from PIL import Image, ImageDraw
import os

# Crear directorio si no existe
os.makedirs("textures/entity", exist_ok=True)

def create_texture(name, size, base_color, details=None):
    """Crear una textura básica"""
    img = Image.new('RGBA', size, (0, 0, 0, 0))  # Fondo transparente
    draw = ImageDraw.Draw(img)
    
    # Color base (rectángulo central)
    margin = size[0] // 8
    draw.rectangle([margin, margin, size[0]-margin, size[1]-margin], fill=base_color)
    
    # Añadir detalles si se especifican
    if details:
        for detail in details:
            if detail['type'] == 'circle':
                draw.ellipse(detail['coords'], fill=detail['color'])
            elif detail['type'] == 'rectangle':
                draw.rectangle(detail['coords'], fill=detail['color'])
    
    # Guardar
    img.save(f"textures/entity/{name}.png", "PNG")
    print(f"✓ Creada: {name}.png ({size[0]}x{size[1]})")

# Texturas ZAYIN (Seguros)
create_texture("one_sin", (64, 64), (139, 69, 19), [  # Marrón
    {'type': 'circle', 'coords': [20, 10, 44, 34], 'color': (255, 215, 0)},  # Dorado
])

create_texture("fairy_festival", (64, 64), (255, 182, 193), [  # Rosa claro
    {'type': 'circle', 'coords': [24, 24, 40, 40], 'color': (255, 105, 180)},  # Rosa fuerte
])

# Texturas TETH (Básicos)
create_texture("punishing_bird", (64, 64), (255, 255, 255), [  # Blanco
    {'type': 'circle', 'coords': [28, 35, 36, 43], 'color': (255, 0, 0)},  # Marca roja
    {'type': 'circle', 'coords': [26, 20, 30, 24], 'color': (0, 0, 0)},     # Ojo izq
    {'type': 'circle', 'coords': [34, 20, 38, 24], 'color': (0, 0, 0)},     # Ojo der
])

create_texture("punishing_bird_angry", (64, 64), (220, 20, 60), [  # Rojo intenso
    {'type': 'rectangle', 'coords': [26, 35, 38, 45], 'color': (139, 0, 0)},  # Mandíbula
    {'type': 'circle', 'coords': [26, 20, 30, 24], 'color': (255, 0, 0)},     # Ojo rojo izq
    {'type': 'circle', 'coords': [34, 20, 38, 24], 'color': (255, 0, 0)},     # Ojo rojo der
])

create_texture("spider_bud", (64, 64), (47, 47, 47), [  # Gris oscuro
    {'type': 'circle', 'coords': [20, 15, 24, 19], 'color': (255, 0, 0)},   # Ojo 1
    {'type': 'circle', 'coords': [40, 15, 44, 19], 'color': (255, 0, 0)},   # Ojo 2
    {'type': 'circle', 'coords': [30, 25, 34, 29], 'color': (255, 0, 0)},   # Ojo 3
    {'type': 'circle', 'coords': [25, 35, 29, 39], 'color': (255, 0, 0)},   # Ojo 4
    {'type': 'circle', 'coords': [35, 35, 39, 39], 'color': (255, 0, 0)},   # Ojo 5
])

create_texture("void_dream", (64, 64), (255, 255, 255), [  # Blanco
    {'type': 'circle', 'coords': [20, 10, 44, 25], 'color': (153, 50, 204)},  # Cabeza púrpura
    {'type': 'circle', 'coords': [24, 14, 28, 18], 'color': (0, 0, 0)},       # Ojo izq
    {'type': 'circle', 'coords': [36, 14, 40, 18], 'color': (0, 0, 0)},       # Ojo der
])

create_texture("void_dream_transformed", (64, 64), (200, 200, 200), [  # Gris claro
    {'type': 'circle', 'coords': [20, 10, 44, 25], 'color': (75, 0, 130)},    # Cabeza púrpura oscura
    {'type': 'circle', 'coords': [24, 14, 28, 18], 'color': (255, 0, 0)},     # Ojo rojo izq
    {'type': 'circle', 'coords': [36, 14, 40, 18], 'color': (255, 0, 0)},     # Ojo rojo der
])

# Texturas HE (Intermedios)
create_texture("der_freischutz", (64, 64), (47, 79, 79), [  # Gris azulado
    {'type': 'rectangle', 'coords': [20, 10, 44, 25], 'color': (139, 69, 19)},  # Sombrero
    {'type': 'rectangle', 'coords': [45, 30, 60, 34], 'color': (160, 82, 45)},  # Mosquete
])

create_texture("funeral_butterflies", (64, 64), (128, 0, 128), [  # Púrpura
    {'type': 'rectangle', 'coords': [20, 20, 44, 50], 'color': (139, 0, 0)},   # Ataúd
    {'type': 'circle', 'coords': [28, 15, 36, 23], 'color': (255, 182, 193)},  # Cabeza
])

create_texture("laetitia", (64, 64), (255, 182, 193), [  # Rosa claro
    {'type': 'circle', 'coords': [24, 10, 40, 26], 'color': (255, 218, 185)},  # Cabeza
    {'type': 'rectangle', 'coords': [20, 26, 44, 50], 'color': (255, 105, 180)}, # Vestido
    {'type': 'circle', 'coords': [28, 14, 32, 18], 'color': (0, 0, 0)},        # Ojo izq
    {'type': 'circle', 'coords': [32, 14, 36, 18], 'color': (0, 0, 0)},        # Ojo der
])

create_texture("laetitia_spider", (64, 64), (139, 0, 0), [  # Rojo oscuro
    {'type': 'circle', 'coords': [24, 24, 40, 40], 'color': (255, 0, 0)},      # Cuerpo
    {'type': 'rectangle', 'coords': [10, 30, 20, 34], 'color': (139, 0, 0)},   # Pata 1
    {'type': 'rectangle', 'coords': [44, 30, 54, 34], 'color': (139, 0, 0)},   # Pata 2
])

create_texture("snow_queen", (64, 64), (176, 224, 230), [  # Azul claro
    {'type': 'circle', 'coords': [24, 10, 40, 26], 'color': (255, 255, 255)},  # Cabeza
    {'type': 'rectangle', 'coords': [20, 26, 44, 50], 'color': (70, 130, 180)}, # Vestido
    {'type': 'rectangle', 'coords': [20, 5, 44, 12], 'color': (176, 196, 222)}, # Corona
])

# Texturas WAW (Peligrosos)
create_texture("queen_hatred", (64, 64), (139, 0, 0), [  # Rojo oscuro
    {'type': 'circle', 'coords': [24, 10, 40, 26], 'color': (245, 245, 220)},  # Cabeza pálida
    {'type': 'rectangle', 'coords': [20, 5, 44, 12], 'color': (255, 215, 0)},  # Corona
    {'type': 'rectangle', 'coords': [18, 26, 46, 55], 'color': (139, 0, 0)},   # Vestido
])

create_texture("queen_hatred_hysteric", (64, 64), (255, 0, 0), [  # Rojo intenso
    {'type': 'circle', 'coords': [24, 10, 40, 26], 'color': (245, 245, 220)},  # Cabeza
    {'type': 'circle', 'coords': [28, 14, 32, 18], 'color': (255, 0, 0)},      # Ojo rojo izq
    {'type': 'circle', 'coords': [32, 14, 36, 18], 'color': (255, 0, 0)},      # Ojo rojo der
])

create_texture("knight_despair", (64, 64), (47, 79, 79), [  # Gris azulado
    {'type': 'rectangle', 'coords': [20, 10, 44, 50], 'color': (192, 192, 192)}, # Armadura
    {'type': 'rectangle', 'coords': [45, 20, 60, 24], 'color': (169, 169, 169)}, # Espada
])

# Texturas WAW - Pájaros (128x128)
create_texture("big_bird", (128, 128), (0, 0, 0), [  # Negro
    {'type': 'circle', 'coords': [30, 30, 38, 38], 'color': (255, 255, 0)},   # Ojo 1
    {'type': 'circle', 'coords': [50, 25, 58, 33], 'color': (255, 255, 0)},   # Ojo 2
    {'type': 'circle', 'coords': [70, 35, 78, 43], 'color': (255, 255, 0)},   # Ojo 3
    {'type': 'circle', 'coords': [40, 50, 48, 58], 'color': (255, 255, 0)},   # Ojo 4
    {'type': 'circle', 'coords': [60, 55, 68, 63], 'color': (255, 255, 0)},   # Ojo 5
])

create_texture("judgement_bird", (128, 128), (0, 0, 0), [  # Negro
    {'type': 'circle', 'coords': [50, 20, 78, 48], 'color': (192, 192, 192)}, # Cabeza
    {'type': 'rectangle', 'coords': [55, 50, 73, 80], 'color': (169, 169, 169)}, # Balanza
])

# Texturas ALEPH (256x256)
create_texture("apocalypse_bird", (256, 256), (0, 0, 0), [  # Negro
    {'type': 'circle', 'coords': [100, 50, 156, 106], 'color': (139, 0, 0)},   # Cuerpo central
    {'type': 'rectangle', 'coords': [80, 120, 176, 200], 'color': (47, 47, 47)}, # Cuerpo inferior
])

# Huevos Especiales (64x64)
create_texture("small_beak", (64, 64), (255, 0, 0), [  # Rojo
    {'type': 'rectangle', 'coords': [28, 10, 36, 20], 'color': (255, 215, 0)}, # Pico
])

create_texture("long_arms", (64, 64), (135, 206, 235), [  # Azul claro
    {'type': 'rectangle', 'coords': [10, 28, 25, 36], 'color': (128, 128, 128)}, # Brazo izq
    {'type': 'rectangle', 'coords': [39, 28, 54, 36], 'color': (128, 128, 128)}, # Brazo der
])

create_texture("big_eyes", (64, 64), (47, 47, 47), [  # Gris oscuro
    {'type': 'circle', 'coords': [15, 15, 25, 25], 'color': (255, 0, 0)},     # Ojo 1
    {'type': 'circle', 'coords': [39, 15, 49, 25], 'color': (0, 255, 0)},     # Ojo 2
    {'type': 'circle', 'coords': [27, 35, 37, 45], 'color': (0, 0, 255)},     # Ojo 3
])

print("\n🎉 ¡Todas las texturas básicas creadas exitosamente!")
print("📁 Ubicación: textures/entity/")
print("🎮 Ahora puedes probar el addon sin errores de texturas")