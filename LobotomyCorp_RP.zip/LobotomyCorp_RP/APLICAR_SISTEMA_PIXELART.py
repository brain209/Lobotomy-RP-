"""
Aplica el sistema completo de pixel art: modelos únicos y texturas funcionales
"""

import os
import shutil
import json

def aplicar_sistema(nombre_entidad, base_path="."):
    """Aplica modelo único y textura pixel art"""
    
    modelo_unique = os.path.join(base_path, f"models/entity/{nombre_entidad}_unique.geo.json")
    modelo_actual = os.path.join(base_path, f"models/entity/{nombre_entidad}.geo.json")
    entity_file = os.path.join(base_path, f"entity/{nombre_entidad}.entity.json")
    
    if not os.path.exists(modelo_unique):
        return False
    
    # Backup
    if os.path.exists(modelo_actual):
        backup = modelo_actual + ".backup3"
        if not os.path.exists(backup):
            shutil.copy2(modelo_actual, backup)
    
    # Aplicar modelo único
    shutil.copy2(modelo_unique, modelo_actual)
    
    # Actualizar entity file
    if os.path.exists(entity_file):
        with open(entity_file, 'r', encoding='utf-8') as f:
            entity_data = json.load(f)
        
        if 'minecraft:client_entity' in entity_data:
            desc = entity_data['minecraft:client_entity']['description']
            if 'textures' in desc:
                for key in desc['textures']:
                    desc['textures'][key] = f"textures/entity/{nombre_entidad}_pixelart"
        
        with open(entity_file, 'w', encoding='utf-8') as f:
            json.dump(entity_data, f, indent=2)
    
    return True

def procesar_todas():
    """Aplica sistema a todas las entidades"""
    
    base_path = "LobotomyCorp_RP" if os.path.exists("LobotomyCorp_RP") else "."
    
    entidades = [
        'snow_queen',
        'punishing_bird',
        'punishing_bird_angry',
        'one_sin',
        'fairy_festival',
        'spider_bud',
    ]
    
    print("=== Aplicando Sistema Pixel Art Completo ===\n")
    
    exitosos = 0
    for entidad in entidades:
        if aplicar_sistema(entidad, base_path):
            print(f"✓ {entidad}: Sistema aplicado")
            exitosos += 1
        else:
            print(f"✗ {entidad}: Error")
    
    print(f"\n✓ {exitosos}/{len(entidades)} entidades actualizadas")
    print("\n¡SISTEMA COMPLETO APLICADO!")
    print("\nCada entidad ahora tiene:")
    print("  - Modelo ÚNICO diseñado específicamente para ella")
    print("  - Textura pixel art funcional creada desde cero")
    print("\nRecarga Minecraft y prueba!")

if __name__ == "__main__":
    procesar_todas()
