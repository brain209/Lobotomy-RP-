"""
Aplica los modelos inteligentes y regenera las texturas HD
"""

import os
import shutil
import json

def aplicar_modelo_smart(nombre_entidad, base_path="."):
    """Aplica el modelo smart a una entidad"""
    
    modelo_smart = os.path.join(base_path, f"models/entity/{nombre_entidad}_smart.geo.json")
    modelo_actual = os.path.join(base_path, f"models/entity/{nombre_entidad}.geo.json")
    
    if not os.path.exists(modelo_smart):
        return False
    
    # Backup del modelo anterior
    backup = modelo_actual + ".old"
    if os.path.exists(modelo_actual) and not os.path.exists(backup):
        shutil.copy2(modelo_actual, backup)
    
    # Aplicar modelo smart
    shutil.copy2(modelo_smart, modelo_actual)
    
    return True

def procesar_todas():
    """Aplica modelos smart a todas las entidades"""
    
    base_path = "LobotomyCorp_RP" if os.path.exists("LobotomyCorp_RP") else "."
    
    entidades = [
        'snow_queen',
        'punishing_bird',
        'punishing_bird_angry',
        'one_sin',
        'fairy_festival',
        'spider_bud',
        'void_dream',
        'void_dream_transformed',
        'der_freischutz',
        'funeral_butterflies',
        'knight_despair',
        'queen_hatred',
        'queen_hatred_hysteric',
    ]
    
    print("=== Aplicando Modelos Inteligentes ===\n")
    
    exitosos = 0
    for entidad in entidades:
        if aplicar_modelo_smart(entidad, base_path):
            print(f"✓ {entidad}: Modelo smart aplicado")
            exitosos += 1
        else:
            print(f"✗ {entidad}: No se encontró modelo smart")
    
    print(f"\n✓ {exitosos}/{len(entidades)} modelos aplicados")
    print("\nAhora regenera las texturas HD con:")
    print("  py LobotomyCorp_RP/REGENERAR_TEXTURAS_HD.py")

if __name__ == "__main__":
    procesar_todas()
