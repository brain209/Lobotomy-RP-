"""
Script para convertir texturas de IA al formato UV de Minecraft Bedrock
Layout estándar de 64x64 compatible con modelos humanoides
"""

from PIL import Image, ImageDraw
import os

def crear_textura_minecraft_layout(imagen_entrada, nombre_salida):
    """
    Convierte una imagen de IA al layout UV estándar de Minecraft (64x64)
    
    Layout:
    - Head: (0,0) 32x16
    - Body: (16,16) 24x16  
    - Arms: (40,16) 16x32
    - Legs: (0,16) 16x32
    """
    
    # Cargar imagen original
    if isinstance(imagen_entrada, str):
        img_original = Image.open(imagen_entrada).convert('RGBA')
    else:
        img_original = imagen_entrada
    
    # Crear textura base 64x64
    textura = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
    
    # Redimensionar imagen original para trabajar con ella
    img_work = img_original.resize((64, 64), Image.Resampling.LANCZOS)
    
    # Extraer colores dominantes de diferentes regiones
    # Región superior = cabeza
    head_region = img_work.crop((16, 0, 48, 32))
    
    # Región media = cuerpo
    body_region = img_work.crop((20, 20, 44, 44))
    
    # Región inferior = piernas
    legs_region = img_work.crop((16, 40, 48, 64))
    
    # CABEZA (0,0) - 32x16 para todas las caras
    # Frente, atrás, arriba, abajo, izquierda, derecha
    head_sample = head_region.resize((8, 8), Image.Resampling.LANCZOS)
    
    # Top (8,0)
    textura.paste(head_sample, (8, 0))
    # Bottom (16,0)
    textura.paste(head_sample, (16, 0))
    # Right (0,8)
    textura.paste(head_sample, (0, 8))
    # Front (8,8)
    textura.paste(head_sample, (8, 8))
    # Left (16,8)
    textura.paste(head_sample, (16, 8))
    # Back (24,8)
    textura.paste(head_sample, (24, 8))
    
    # CUERPO (16,16) - 24x16
    body_sample = body_region.resize((8, 12), Image.Resampling.LANCZOS)
    
    # Top (20,16)
    body_top = body_sample.crop((0, 0, 8, 4))
    textura.paste(body_top, (20, 16))
    # Bottom (28,16)
    textura.paste(body_top, (28, 16))
    # Right (16,20)
    body_side = body_sample.crop((0, 0, 4, 12))
    textura.paste(body_side, (16, 20))
    # Front (20,20)
    textura.paste(body_sample, (20, 20))
    # Left (28,20)
    textura.paste(body_side, (28, 20))
    # Back (32,20)
    textura.paste(body_sample, (32, 20))
    
    # BRAZO DERECHO (40,16) - 16x16
    arm_sample = body_region.resize((4, 12), Image.Resampling.LANCZOS)
    
    # Top (44,16)
    arm_top = arm_sample.crop((0, 0, 4, 4))
    textura.paste(arm_top, (44, 16))
    # Bottom (48,16)
    textura.paste(arm_top, (48, 16))
    # Outer (40,20)
    textura.paste(arm_sample, (40, 20))
    # Front (44,20)
    textura.paste(arm_sample, (44, 20))
    # Inner (48,20)
    textura.paste(arm_sample, (48, 20))
    # Back (52,20)
    textura.paste(arm_sample, (52, 20))
    
    # PIERNA DERECHA (0,16) - 16x16
    leg_sample = legs_region.resize((4, 12), Image.Resampling.LANCZOS)
    
    # Top (4,16)
    leg_top = leg_sample.crop((0, 0, 4, 4))
    textura.paste(leg_top, (4, 16))
    # Bottom (8,16)
    textura.paste(leg_top, (8, 16))
    # Outer (0,20)
    textura.paste(leg_sample, (0, 20))
    # Front (4,20)
    textura.paste(leg_sample, (4, 20))
    # Inner (8,20)
    textura.paste(leg_sample, (8, 20))
    # Back (12,20)
    textura.paste(leg_sample, (12, 20))
    
    # Guardar
    output_path = f"textures/entity/{nombre_salida}.png"
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    textura.save(output_path)
    print(f"✓ Textura creada: {output_path}")
    
    return textura


def procesar_todas_texturas():
    """Procesa todas las texturas PNG en el directorio actual"""
    
    texturas_dir = "textures/entity"
    
    if not os.path.exists(texturas_dir):
        print(f"Error: No existe el directorio {texturas_dir}")
        return
    
    archivos = [f for f in os.listdir(texturas_dir) if f.endswith('.png')]
    
    if not archivos:
        print("No se encontraron archivos PNG para procesar")
        return
    
    print(f"Encontrados {len(archivos)} archivos PNG")
    print("Convirtiendo al formato UV de Minecraft...\n")
    
    for archivo in archivos:
        nombre_base = archivo.replace('.png', '')
        ruta_entrada = os.path.join(texturas_dir, archivo)
        
        try:
            crear_textura_minecraft_layout(ruta_entrada, f"{nombre_base}_fixed")
        except Exception as e:
            print(f"✗ Error procesando {archivo}: {e}")


if __name__ == "__main__":
    print("=== Convertidor de Texturas a Formato Minecraft ===\n")
    procesar_todas_texturas()
    print("\n¡Proceso completado!")
