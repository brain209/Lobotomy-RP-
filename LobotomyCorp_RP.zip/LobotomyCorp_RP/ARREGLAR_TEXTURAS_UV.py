"""
Script para arreglar texturas de IA y adaptarlas al UV mapping de los modelos
Genera texturas de colores sólidos basadas en las texturas de IA existentes
"""

from PIL import Image, ImageDraw, ImageStat
import json
import os

def extraer_color_dominante(imagen, x, y, w, h):
    """Extrae el color promedio de una región de la imagen"""
    try:
        region = imagen.crop((max(0, x), max(0, y), min(imagen.width, x + w), min(imagen.height, y + h)))
        stat = ImageStat.Stat(region)
        # Obtener color promedio
        r, g, b = [int(c) for c in stat.mean[:3]]
        return (r, g, b, 255)
    except:
        return (128, 128, 128, 255)

def analizar_modelo_uv(modelo_path):
    """Analiza un modelo .geo.json y extrae información de UV mapping"""
    with open(modelo_path, 'r', encoding='utf-8') as f:
        modelo = json.load(f)
    
    geometry = modelo['minecraft:geometry'][0]
    texture_width = geometry['description']['texture_width']
    texture_height = geometry['description']['texture_height']
    
    # Extraer todos los cubos con sus UVs
    cubos = []
    for bone in geometry['bones']:
        if 'cubes' in bone:
            for cube in bone['cubes']:
                if 'uv' in cube:
                    cubos.append({
                        'bone': bone['name'],
                        'origin': cube['origin'],
                        'size': cube['size'],
                        'uv': cube['uv']
                    })
    
    return {
        'texture_width': texture_width,
        'texture_height': texture_height,
        'cubos': cubos
    }

def generar_textura_desde_ia(imagen_ia_path, modelo_path, output_path):
    """
    Genera una textura compatible con el modelo usando la imagen de IA como referencia
    """
    # Cargar imagen de IA
    img_ia = Image.open(imagen_ia_path).convert('RGBA')
    
    # Analizar modelo
    info_modelo = analizar_modelo_uv(modelo_path)
    
    # Crear textura vacía
    textura = Image.new('RGBA', 
                        (info_modelo['texture_width'], info_modelo['texture_height']), 
                        (0, 0, 0, 0))
    
    draw = ImageDraw.Draw(textura)
    
    # Redimensionar imagen IA para análisis
    img_ia_work = img_ia.resize((64, 64), Image.Resampling.LANCZOS)
    
    # Mapear regiones de la imagen IA a colores
    colores_regiones = {
        'superior': extraer_color_dominante(img_ia_work, 16, 0, 32, 21),
        'media': extraer_color_dominante(img_ia_work, 16, 21, 32, 21),
        'inferior': extraer_color_dominante(img_ia_work, 16, 42, 32, 22),
        'detalle1': extraer_color_dominante(img_ia_work, 0, 0, 16, 32),
        'detalle2': extraer_color_dominante(img_ia_work, 48, 0, 16, 32),
    }
    
    print(f"  Colores extraídos: Superior RGB{colores_regiones['superior'][:3]}, Media RGB{colores_regiones['media'][:3]}")
    
    # Llenar toda la textura con el color base primero
    draw.rectangle([0, 0, info_modelo['texture_width'], info_modelo['texture_height']], 
                   fill=colores_regiones['media'])
    
    # Llenar cada cubo del modelo con colores apropiados
    for cubo in info_modelo['cubos']:
        uv_x, uv_y = cubo['uv']
        size_x, size_y, size_z = cubo['size']
        bone_name = cubo['bone']
        
        # Determinar color según el bone
        if 'head' in bone_name.lower() or 'crown' in bone_name.lower():
            color = colores_regiones['superior']
        elif 'body' in bone_name.lower() or 'dress' in bone_name.lower() or 'torso' in bone_name.lower():
            color = colores_regiones['media']
        elif 'leg' in bone_name.lower() or 'foot' in bone_name.lower():
            color = colores_regiones['inferior']
        elif 'arm' in bone_name.lower():
            color = colores_regiones['detalle1']
        elif 'spear' in bone_name.lower() or 'wing' in bone_name.lower() or 'tail' in bone_name.lower():
            color = colores_regiones['detalle2']
        else:
            color = colores_regiones['media']
        
        # Calcular dimensiones UV para el cubo (formato estándar de Minecraft)
        width_uv = int(abs(size_x) * 2 + abs(size_z) * 2)
        height_uv = int(abs(size_z) + abs(size_y))
        
        # Dibujar rectángulo en la posición UV
        try:
            draw.rectangle(
                [int(uv_x), int(uv_y), int(uv_x + width_uv), int(uv_y + height_uv)],
                fill=color
            )
        except:
            pass
    
    # Guardar textura
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    textura.save(output_path)
    print(f"  ✓ Textura generada: {output_path}")
    
    return textura

def procesar_entidad(nombre_entidad, base_path="."):
    """Procesa una entidad específica"""
    modelo_path = os.path.join(base_path, f"models/entity/{nombre_entidad}.geo.json")
    textura_ia_path = os.path.join(base_path, f"textures/entity/{nombre_entidad}.png")
    output_path = os.path.join(base_path, f"textures/entity/{nombre_entidad}_fixed.png")
    
    if not os.path.exists(modelo_path):
        print(f"  ✗ No se encontró el modelo: {modelo_path}")
        return False
    
    if not os.path.exists(textura_ia_path):
        print(f"  ✗ No se encontró la textura: {textura_ia_path}")
        return False
    
    try:
        generar_textura_desde_ia(textura_ia_path, modelo_path, output_path)
        return True
    except Exception as e:
        print(f"  ✗ Error procesando {nombre_entidad}: {e}")
        import traceback
        traceback.print_exc()
        return False

def procesar_todas():
    """Procesa todas las entidades que tienen modelo y textura"""
    # Detectar si estamos en LobotomyCorp_RP o en el directorio padre
    if os.path.exists("models/entity"):
        base_path = "."
    elif os.path.exists("LobotomyCorp_RP/models/entity"):
        base_path = "LobotomyCorp_RP"
    else:
        print("Error: No se encontró el directorio models/entity")
        print(f"Directorio actual: {os.getcwd()}")
        return
    
    print(f"Usando directorio base: {os.path.abspath(base_path)}\n")
    
    entidades = [
        'snow_queen',
        'punishing_bird',
        'punishing_bird_angry',
        'one_sin',
        'fairy_festival',
        'spider_bud',
        'void_dream',
        'void_dream_transformed',
        'der_freischutz',
        'funeral_butterflies',
        'knight_despair',
        'queen_hatred',
        'queen_hatred_hysteric',
    ]
    
    print("=== Arreglando Texturas UV ===\n")
    
    exitosos = 0
    fallidos = 0
    
    for entidad in entidades:
        print(f"Procesando: {entidad}")
        if procesar_entidad(entidad, base_path):
            exitosos += 1
        else:
            fallidos += 1
    
    print(f"\n=== Resumen ===")
    print(f"Exitosos: {exitosos}")
    print(f"Fallidos: {fallidos}")
    
    if exitosos > 0:
        print(f"\n✓ Las texturas _fixed.png están listas en {os.path.join(base_path, 'textures/entity/')}")
        print("Ahora actualiza los archivos .entity.json para usar las texturas _fixed.png")

if __name__ == "__main__":
    procesar_todas()
