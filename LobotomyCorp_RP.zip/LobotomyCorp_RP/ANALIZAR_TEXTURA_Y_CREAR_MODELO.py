"""
Analiza una textura de Leonardo AI y genera información para crear un modelo que coincida
"""

from PIL import Image
import json
import os

def analizar_textura(imagen_path):
    """
    Analiza una textura de Leonardo AI y detecta características
    """
    img = Image.open(imagen_path).convert('RGBA')
    width, height = img.size
    
    print(f"\n=== Análisis de Textura: {os.path.basename(imagen_path)} ===")
    print(f"Dimensiones: {width}x{height}")
    
    # Dividir la imagen en regiones para análisis
    regiones = {
        'cabeza': img.crop((int(width*0.25), 0, int(width*0.75), int(height*0.25))),
        'torso_superior': img.crop((int(width*0.25), int(height*0.25), int(width*0.75), int(height*0.5))),
        'torso_inferior': img.crop((int(width*0.25), int(height*0.5), int(width*0.75), int(height*0.75))),
        'piernas': img.crop((int(width*0.25), int(height*0.75), int(width*0.75), height)),
        'brazo_izq': img.crop((0, int(height*0.25), int(width*0.25), int(height*0.6))),
        'brazo_der': img.crop((int(width*0.75), int(height*0.25), width, int(height*0.6))),
    }
    
    # Analizar cada región
    print("\nRegiones detectadas:")
    for nombre, region in regiones.items():
        # Calcular color promedio
        pixels = list(region.getdata())
        r_avg = sum(p[0] for p in pixels) / len(pixels)
        g_avg = sum(p[1] for p in pixels) / len(pixels)
        b_avg = sum(p[2] for p in pixels) / len(pixels)
        a_avg = sum(p[3] for p in pixels) / len(pixels)
        
        # Detectar si la región tiene contenido (no es transparente)
        tiene_contenido = a_avg > 50
        
        if tiene_contenido:
            print(f"  {nombre}: RGB({int(r_avg)}, {int(g_avg)}, {int(b_avg)}) - Opacidad: {int(a_avg)}")
            
            # Guardar región para inspección visual
            output_dir = "textures/entity/analisis"
            os.makedirs(output_dir, exist_ok=True)
            region.save(f"{output_dir}/{os.path.basename(imagen_path).replace('.png', '')}_{nombre}.png")
    
    print(f"\nRegiones guardadas en: textures/entity/analisis/")
    print("\nRecomendaciones para el modelo:")
    print("1. Revisa las imágenes de análisis para ver qué partes tiene la textura")
    print("2. Crea cubos en el modelo que correspondan a cada región visible")
    print("3. Ajusta el UV mapping para que cada cubo tome la región correcta")
    
    return regiones

def generar_modelo_base(nombre_entidad, info_regiones):
    """
    Genera un modelo base simple que coincide con las regiones detectadas
    """
    modelo = {
        "format_version": "1.12.0",
        "minecraft:geometry": [{
            "description": {
                "identifier": f"geometry.{nombre_entidad}",
                "texture_width": 64,
                "texture_height": 64,
                "visible_bounds_width": 2,
                "visible_bounds_height": 3,
                "visible_bounds_offset": [0, 1.5, 0]
            },
            "bones": [
                {
                    "name": "root",
                    "pivot": [0, 0, 0]
                },
                {
                    "name": "body",
                    "parent": "root",
                    "pivot": [0, 12, 0],
                    "cubes": [{
                        "origin": [-4, 12, -2],
                        "size": [8, 12, 4],
                        "uv": [16, 16]
                    }]
                },
                {
                    "name": "head",
                    "parent": "body",
                    "pivot": [0, 24, 0],
                    "cubes": [{
                        "origin": [-4, 24, -4],
                        "size": [8, 8, 8],
                        "uv": [0, 0]
                    }]
                },
                {
                    "name": "left_arm",
                    "parent": "body",
                    "pivot": [-5, 22, 0],
                    "cubes": [{
                        "origin": [-8, 12, -2],
                        "size": [4, 12, 4],
                        "uv": [40, 16]
                    }]
                },
                {
                    "name": "right_arm",
                    "parent": "body",
                    "pivot": [5, 22, 0],
                    "cubes": [{
                        "origin": [4, 12, -2],
                        "size": [4, 12, 4],
                        "uv": [40, 16]
                    }]
                },
                {
                    "name": "left_leg",
                    "parent": "root",
                    "pivot": [-2, 12, 0],
                    "cubes": [{
                        "origin": [-4, 0, -2],
                        "size": [4, 12, 4],
                        "uv": [0, 16]
                    }]
                },
                {
                    "name": "right_leg",
                    "parent": "root",
                    "pivot": [2, 12, 0],
                    "cubes": [{
                        "origin": [0, 0, -2],
                        "size": [4, 12, 4],
                        "uv": [0, 16]
                    }]
                }
            ]
        }]
    }
    
    return modelo

def procesar_entidad(nombre_entidad, base_path="."):
    """Analiza la textura de una entidad"""
    textura_path = os.path.join(base_path, f"textures/entity/{nombre_entidad}.png")
    
    if not os.path.exists(textura_path):
        print(f"✗ No se encontró la textura: {textura_path}")
        return False
    
    try:
        regiones = analizar_textura(textura_path)
        
        # Generar modelo base
        modelo = generar_modelo_base(nombre_entidad, regiones)
        output_path = os.path.join(base_path, f"models/entity/{nombre_entidad}_auto.geo.json")
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(modelo, f, indent=2)
        
        print(f"\n✓ Modelo base generado: {output_path}")
        print("Este es un modelo básico. Revisa las imágenes de análisis y ajusta el modelo manualmente.")
        
        return True
    except Exception as e:
        print(f"✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return False

def procesar_todas():
    """Analiza todas las texturas"""
    if os.path.exists("textures/entity"):
        base_path = "."
    elif os.path.exists("LobotomyCorp_RP/textures/entity"):
        base_path = "LobotomyCorp_RP"
    else:
        print("Error: No se encontró el directorio textures/entity")
        return
    
    entidades = [
        'snow_queen',
        'punishing_bird',
        'punishing_bird_angry',
        'one_sin',
        'fairy_festival',
        'spider_bud',
        'void_dream',
        'void_dream_transformed',
        'der_freischutz',
        'funeral_butterflies',
        'knight_despair',
        'queen_hatred',
        'queen_hatred_hysteric',
    ]
    
    print("=== Analizando Texturas de Leonardo AI ===")
    print("Este script dividirá cada textura en regiones para que puedas ver")
    print("exactamente qué partes tiene cada personaje.\n")
    
    for entidad in entidades:
        print(f"\n{'='*60}")
        procesar_entidad(entidad, base_path)
    
    print("\n\n=== Análisis Completo ===")
    print("\nPróximos pasos:")
    print("1. Revisa las imágenes en textures/entity/analisis/")
    print("2. Para cada entidad, verás sus partes divididas (cabeza, torso, brazos, etc.)")
    print("3. Usa esta información para ajustar los modelos manualmente")
    print("4. O dime qué ves en las texturas y creo modelos personalizados")

if __name__ == "__main__":
    procesar_todas()
