"""
Sistema completo para crear texturas UV y modelos desde texturas de Leonardo AI
Genera texturas UV correctas y modelos funcionales
"""

from PIL import Image, ImageDraw, ImageEnhance, ImageFilter
import json
import os

def crear_textura_uv_minecraft(imagen_ia_path, output_path):
    """
    Crea una textura UV de Minecraft desde una imagen de Leonardo AI
    Layout estándar de Minecraft para entidades humanoides
    """
    # Cargar imagen de IA
    img = Image.open(imagen_ia_path).convert('RGBA')
    
    # Crear textura UV vacía 64x64
    texture = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
    
    # Redimensionar imagen para trabajar
    img_work = img.resize((64, 64), Image.Resampling.LANCZOS)
    
    # Mejorar calidad
    img_work = img_work.filter(ImageFilter.SHARPEN)
    enhancer = ImageEnhance.Contrast(img_work)
    img_work = enhancer.enhance(1.2)
    
    # Extraer regiones de la imagen frontal
    # Cabeza (parte superior central)
    head_region = img_work.crop((20, 0, 44, 24))
    
    # Cuerpo (parte media)
    body_region = img_work.crop((20, 20, 44, 40))
    
    # Parte inferior (vestido/piernas)
    lower_region = img_work.crop((16, 40, 48, 64))
    
    # Brazos (laterales)
    left_arm_region = img_work.crop((8, 20, 20, 40))
    right_arm_region = img_work.crop((44, 20, 56, 40))
    
    # === CABEZA (0,0) - 32x16 ===
    # Layout: [right][top][left][front][back][bottom]
    head_size = 8
    
    # Top (8,0)
    head_top = head_region.crop((4, 0, 12, 8))
    texture.paste(head_top.resize((head_size, head_size), Image.Resampling.LANCZOS), (8, 0))
    
    # Bottom (16,0)
    texture.paste(head_top.resize((head_size, head_size), Image.Resampling.LANCZOS), (16, 0))
    
    # Right side (0,8)
    head_side = head_region.crop((0, 4, 4, 12))
    texture.paste(head_side.resize((head_size, head_size), Image.Resampling.LANCZOS), (0, 8))
    
    # Front (8,8)
    head_front = head_region.crop((4, 4, 12, 12))
    texture.paste(head_front.resize((head_size, head_size), Image.Resampling.LANCZOS), (8, 8))
    
    # Left side (16,8)
    texture.paste(head_side.resize((head_size, head_size), Image.Resampling.LANCZOS), (16, 8))
    
    # Back (24,8)
    texture.paste(head_front.resize((head_size, head_size), Image.Resampling.LANCZOS), (24, 8))
    
    # === CUERPO (16,20) - 24x16 ===
    body_width = 8
    body_height = 12
    
    # Top (20,16)
    body_top = body_region.crop((4, 0, 12, 4))
    texture.paste(body_top.resize((body_width, 4), Image.Resampling.LANCZOS), (20, 16))
    
    # Bottom (28,16)
    texture.paste(body_top.resize((body_width, 4), Image.Resampling.LANCZOS), (28, 16))
    
    # Right (16,20)
    body_side = body_region.crop((0, 0, 4, 16))
    texture.paste(body_side.resize((4, body_height), Image.Resampling.LANCZOS), (16, 20))
    
    # Front (20,20)
    body_front = body_region.crop((4, 0, 12, 16))
    texture.paste(body_front.resize((body_width, body_height), Image.Resampling.LANCZOS), (20, 20))
    
    # Left (28,20)
    texture.paste(body_side.resize((4, body_height), Image.Resampling.LANCZOS), (28, 20))
    
    # Back (32,20)
    texture.paste(body_front.resize((body_width, body_height), Image.Resampling.LANCZOS), (32, 20))
    
    # === VESTIDO/PARTE INFERIOR (0,32) - 32x16 ===
    dress_width = 16
    dress_height = 12
    
    # Top (4,32)
    dress_top = lower_region.crop((8, 0, 24, 8))
    texture.paste(dress_top.resize((dress_width, dress_width), Image.Resampling.LANCZOS), (4, 32))
    
    # Bottom (20,32)
    texture.paste(dress_top.resize((dress_width, dress_width), Image.Resampling.LANCZOS), (20, 32))
    
    # Front (4,48)
    dress_front = lower_region.crop((8, 0, 24, 20))
    texture.paste(dress_front.resize((dress_width, dress_height), Image.Resampling.LANCZOS), (4, 48))
    
    # Back (20,48)
    texture.paste(dress_front.resize((dress_width, dress_height), Image.Resampling.LANCZOS), (20, 48))
    
    # === BRAZOS (40,20) - 16x16 cada uno ===
    arm_width = 4
    arm_height = 12
    
    # Brazo izquierdo
    left_arm_front = left_arm_region.crop((2, 0, 10, 16))
    texture.paste(left_arm_front.resize((arm_width, arm_height), Image.Resampling.LANCZOS), (44, 20))
    
    # Brazo derecho  
    right_arm_front = right_arm_region.crop((2, 0, 10, 16))
    texture.paste(right_arm_front.resize((arm_width, arm_height), Image.Resampling.LANCZOS), (52, 20))
    
    # Guardar
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    texture.save(output_path)
    print(f"  ✓ Textura UV creada: {os.path.basename(output_path)}")
    
    return texture

def crear_modelo_estandar(nombre_entidad):
    """
    Crea un modelo estándar funcional para entidades humanoides
    """
    modelo = {
        "format_version": "1.12.0",
        "minecraft:geometry": [{
            "description": {
                "identifier": f"geometry.{nombre_entidad}",
                "texture_width": 64,
                "texture_height": 64,
                "visible_bounds_width": 2,
                "visible_bounds_height": 3,
                "visible_bounds_offset": [0, 1.5, 0]
            },
            "bones": [
                {
                    "name": "root",
                    "pivot": [0, 0, 0]
                },
                {
                    "name": "dress",
                    "parent": "root",
                    "pivot": [0, 6, 0],
                    "cubes": [{
                        "origin": [-8, 0, -8],
                        "size": [16, 12, 16],
                        "uv": [0, 32]
                    }]
                },
                {
                    "name": "body",
                    "parent": "dress",
                    "pivot": [0, 18, 0],
                    "cubes": [{
                        "origin": [-4, 12, -2],
                        "size": [8, 12, 4],
                        "uv": [16, 20]
                    }]
                },
                {
                    "name": "head",
                    "parent": "body",
                    "pivot": [0, 24, 0],
                    "cubes": [{
                        "origin": [-4, 24, -4],
                        "size": [8, 8, 8],
                        "uv": [0, 0]
                    }]
                },
                {
                    "name": "left_arm",
                    "parent": "body",
                    "pivot": [-5, 22, 0],
                    "cubes": [{
                        "origin": [-7, 12, -2],
                        "size": [4, 12, 4],
                        "uv": [40, 20]
                    }]
                },
                {
                    "name": "right_arm",
                    "parent": "body",
                    "pivot": [5, 22, 0],
                    "cubes": [{
                        "origin": [3, 12, -2],
                        "size": [4, 12, 4],
                        "uv": [48, 20]
                    }]
                }
            ]
        }]
    }
    
    return modelo

def procesar_entidad(nombre_entidad, base_path="."):
    """Procesa una entidad completa"""
    textura_ia = os.path.join(base_path, f"textures/entity/{nombre_entidad}.png")
    textura_output = os.path.join(base_path, f"textures/entity/{nombre_entidad}_uv.png")
    modelo_output = os.path.join(base_path, f"models/entity/{nombre_entidad}_uv.geo.json")
    
    if not os.path.exists(textura_ia):
        print(f"  ✗ No se encontró textura original")
        return False
    
    try:
        # Crear textura UV
        crear_textura_uv_minecraft(textura_ia, textura_output)
        
        # Crear modelo
        modelo = crear_modelo_estandar(nombre_entidad)
        with open(modelo_output, 'w', encoding='utf-8') as f:
            json.dump(modelo, f, indent=2)
        
        print(f"  ✓ Modelo UV creado: {os.path.basename(modelo_output)}")
        
        return True
        
    except Exception as e:
        print(f"  ✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return False

def procesar_todas():
    """Procesa todas las entidades"""
    base_path = "LobotomyCorp_RP" if os.path.exists("LobotomyCorp_RP") else "."
    
    entidades = [
        'snow_queen',
        'punishing_bird',
        'punishing_bird_angry',
        'one_sin',
        'fairy_festival',
        'spider_bud',
        'void_dream',
        'void_dream_transformed',
        'der_freischutz',
        'funeral_butterflies',
        'knight_despair',
        'queen_hatred',
        'queen_hatred_hysteric',
    ]
    
    print("=== Sistema Completo de Texturas UV ===\n")
    print("Creando texturas UV correctas y modelos funcionales...\n")
    
    exitosos = 0
    for entidad in entidades:
        print(f"Procesando: {entidad}")
        if procesar_entidad(entidad, base_path):
            exitosos += 1
    
    print(f"\n✓ {exitosos}/{len(entidades)} entidades procesadas")
    print("\nArchivos creados:")
    print("  - *_uv.png: Texturas UV correctas")
    print("  - *_uv.geo.json: Modelos funcionales")
    print("\nAhora aplica con: py LobotomyCorp_RP/APLICAR_SISTEMA_UV.py")

if __name__ == "__main__":
    procesar_todas()
